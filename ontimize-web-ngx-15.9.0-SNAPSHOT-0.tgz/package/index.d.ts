/// <amd-module name="ontimize-web-ngx" />
export * from './public-api';
