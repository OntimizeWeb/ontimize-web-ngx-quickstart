import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import type { ODialogConfig } from '../shared';
import { ODialogInternalComponent } from '../shared/components/dialog/o-dialog-internal.component';
import * as i0 from "@angular/core";
export declare class OErrorDialogManager {
    protected ng2Dialog: MatDialog;
    protected errorDialogSubscription: Promise<boolean>;
    dialogRef: MatDialogRef<ODialogInternalComponent>;
    constructor(ng2Dialog: MatDialog);
    protected restart(): void;
    openErrorDialog(err?: any): Promise<boolean>;
    protected openDialog(observer: any): void;
    alert(title: string, message: string, config?: ODialogConfig): Promise<any>;
    static ɵfac: i0.ɵɵFactoryDeclaration<OErrorDialogManager, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OErrorDialogManager>;
}
