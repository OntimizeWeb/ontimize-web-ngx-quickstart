import { Observable } from "rxjs";
import { BaseService } from "./base-service.class";
import { Injector } from "@angular/core";
import { ServiceResponse } from "../interfaces/service-response.interface";
import { PaginationContext } from "../interfaces/pagination-context.interface";
export declare abstract class BaseDataService<T> extends BaseService<ServiceResponse> {
    protected injector: Injector;
    constructor(injector: Injector);
    path: string;
    abstract query(...args: [any, ...any[]]): Observable<T>;
    abstract queryById(...args: [any, ...any[]]): Observable<T>;
    abstract advancedQuery(...args: [any, ...any[]]): Observable<T>;
    abstract insert(...args: [any, ...any[]]): Observable<T>;
    abstract update(...args: [any, ...any[]]): Observable<T>;
    abstract delete(...args: [any, ...any[]]): Observable<T>;
    clientErrorFallback(errorCode: number): void;
    setPaginationContext(context: PaginationContext): void;
}
