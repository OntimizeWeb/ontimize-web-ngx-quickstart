import { HttpErrorResponse, HttpResponse } from '@angular/common/http';
import { IServiceResponseAdapter } from '../interfaces/service-response-adapter.interface';
import { BaseServiceResponse } from './base-service-response.class';
import * as i0 from "@angular/core";
export declare class BaseServiceResponseAdapter implements IServiceResponseAdapter<BaseServiceResponse> {
    adapt(res: HttpResponse<any>): any;
    adaptError?(error: HttpErrorResponse): HttpErrorResponse;
    context: any;
    static ɵfac: i0.ɵɵFactoryDeclaration<BaseServiceResponseAdapter, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<BaseServiceResponseAdapter>;
}
