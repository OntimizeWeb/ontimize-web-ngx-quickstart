import { Observable } from "rxjs";
import { ServiceResponse } from "../../interfaces/service-response.interface";
export declare class BaseRequestArgument {
    request(method: string, service: any, queryArguments: any): Observable<ServiceResponse>;
    parseQueryParameters(args: any): any;
    getIdFromFilter(filter: any): any;
}
