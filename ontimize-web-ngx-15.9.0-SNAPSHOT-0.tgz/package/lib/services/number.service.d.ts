import { Injector } from '@angular/core';
import { IRealPipeArgument } from '../pipes';
import { OTranslateService } from './translate/o-translate.service';
import * as i0 from "@angular/core";
export declare class NumberService {
    protected injector: Injector;
    static DEFAULT_DECIMAL_DIGITS: number;
    protected minDecimalDigits: number;
    protected maxDecimalDigits: number;
    protected locale: string;
    protected translateService: OTranslateService;
    constructor(injector: Injector);
    getIntegerValue(value: any, args: any): any;
    getRealValue(value: any, args: IRealPipeArgument): any;
    getPercentValue(value: any, args: any): string;
    private truncate;
    private parseRealValue;
    static ɵfac: i0.ɵɵFactoryDeclaration<NumberService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<NumberService>;
}
