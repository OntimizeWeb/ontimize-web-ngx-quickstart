import { Observable } from 'rxjs';
import { JSONAPIService } from './jsonapi.service';
import * as i0 from "@angular/core";
export declare class JSONAPIPreferencesService extends JSONAPIService {
    configureService(config: any): void;
    protected parseObjectToPreference(preferencesparams: object): object;
    saveAsPreferences(preferencesparams: object): Observable<any>;
    savePreferences(id: number, preferencesparams: object): Observable<any>;
    getPreferences(entity: string, service: string, type: string): Observable<any>;
    deletePreferences(id?: number): Observable<any>;
    static ɵfac: i0.ɵɵFactoryDeclaration<JSONAPIPreferencesService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<JSONAPIPreferencesService>;
}
