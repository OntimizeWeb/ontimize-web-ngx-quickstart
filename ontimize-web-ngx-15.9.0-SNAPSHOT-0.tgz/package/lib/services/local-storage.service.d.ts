import { EventEmitter, Injector } from '@angular/core';
import { ILocalStorageComponent } from '../interfaces/local-storage-component.interface';
import { ILocalStorageService } from '../interfaces/local-service.interface';
import * as i0 from "@angular/core";
export declare class LocalStorageService implements ILocalStorageService {
    protected injector: Injector;
    static COMPONENTS_STORAGE_KEY: string;
    static USERS_STORAGE_KEY: string;
    static SESSION_STORAGE_KEY: string;
    onRouteChange: EventEmitter<any>;
    onSetLocalStorage: EventEmitter<any>;
    private _config;
    private _router;
    private authService;
    constructor(injector: Injector);
    getComponentStorage(comp: ILocalStorageComponent, routeKey?: string): any;
    updateComponentStorage(comp: ILocalStorageComponent, routeKey?: string): void;
    private getAppComponentData;
    updateAppComponentStorage(componentKey: string, componentData: object): void;
    getSessionUserComponentsData(): object;
    storeSessionUserComponentsData(componentsData: object): void;
    private storeComponentInSessionUser;
    getStoredData(): object;
    setBackwardCompatibility(): void;
    setLocalStorage(appData: any): void;
    removeStoredData(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<LocalStorageService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<LocalStorageService>;
}
