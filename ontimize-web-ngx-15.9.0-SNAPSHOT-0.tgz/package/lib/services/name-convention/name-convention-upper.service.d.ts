import { BaseNameConvention } from './base-name-convention.service';
export declare class NameConventionUpper extends BaseNameConvention {
    parseToStringCase(value: any): any;
    parseOppositeToStringCase(value: any): any;
}
