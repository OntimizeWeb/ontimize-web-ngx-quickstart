import { OListComponent } from '../../components/list/o-list.component';
import { AbstractComponentStateService } from './o-component-state.service';
import { OListComponentStateClass } from './o-list-component-state.class';
import * as i0 from "@angular/core";
export declare class OListComponentStateService extends AbstractComponentStateService<OListComponentStateClass, OListComponent> {
    initialize(component: OListComponent): void;
    initializeState(state: OListComponentStateClass): void;
    getDataToStore(): any;
    refreshSelection(): void;
    protected getSelectionState(): any[];
    static ɵfac: i0.ɵɵFactoryDeclaration<OListComponentStateService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OListComponentStateService>;
}
