import { DefaultServiceComponentStateClass } from './o-component-state.class';
export declare class OListComponentStateClass extends DefaultServiceComponentStateClass {
    protected 'sort-columns': string;
    'quickFilterActiveColumns': string;
    selection: any[];
    get sortColumns(): string;
    set sortColumns(value: string);
}
