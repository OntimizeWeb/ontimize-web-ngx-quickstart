import { OTableComponent } from '../../components/table/o-table.component';
import { OFilterDefinition } from '../../types/o-filter-definition.type';
import { OColumnSearchable } from '../../types/table/o-column-searchable.type';
import { OTableConfiguration } from '../../types/table/o-table-configuration.type';
import { AbstractComponentStateService } from './o-component-state.service';
import { OTableComponentStateClass } from './o-table-component-state.class';
import * as i0 from "@angular/core";
export declare class OTableComponentStateService extends AbstractComponentStateService<OTableComponentStateClass, OTableComponent> {
    initialize(component: OTableComponent): void;
    initializeState(state: OTableComponentStateClass): void;
    refreshSelection(): void;
    getDataToStore(): any;
    storeFilter(filter: OFilterDefinition): void;
    storeConfiguration(configurationAgs: OTableConfiguration, tableProperties: any[]): void;
    protected getTablePropertiesToStore(properties: string[]): any;
    protected getTablePropertyToStore(property: string): any;
    protected getColumnsDisplayState(): {
        'oColumns-display': any[];
        'select-column-visible': boolean;
    };
    protected getColumnsQuickFilterState(): {
        oColumns: OColumnSearchable[];
        'filter-case-sensitive': boolean;
        filter: string;
    };
    protected getFilterBuilderState(): any;
    protected getColumnFiltersState(): {};
    protected getPageState(): any;
    protected getSelectionState(): any;
    protected getInitialConfigurationState(): any;
    protected getSortState(): {
        'sort-columns': string;
    };
    static ɵfac: i0.ɵɵFactoryDeclaration<OTableComponentStateService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OTableComponentStateService>;
}
