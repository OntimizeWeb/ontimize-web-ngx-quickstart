import { DefaultComponentStateClass } from './o-component-state.class';
export declare class OAppSidenavComponentStateClass extends DefaultComponentStateClass {
    menu: {
        id: string;
        opened: boolean;
    }[];
}
