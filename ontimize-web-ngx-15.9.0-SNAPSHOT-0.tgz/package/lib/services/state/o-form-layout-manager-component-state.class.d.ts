import { DefaultComponentStateClass } from './o-component-state.class';
export declare class OFormLayoutManagerComponentStateClass extends DefaultComponentStateClass {
    selectedIndex: number;
    tabsData: any[];
    queryParams: any;
    url: any;
}
