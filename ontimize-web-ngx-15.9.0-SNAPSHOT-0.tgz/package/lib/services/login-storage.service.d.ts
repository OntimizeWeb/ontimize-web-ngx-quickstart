import { Injector } from '@angular/core';
import { SessionInfo } from '../types/session-info.type';
import * as i0 from "@angular/core";
export declare class LoginStorageService {
    protected injector: Injector;
    private _config;
    _localStorageKey: string;
    constructor(injector: Injector);
    getSessionInfo(): SessionInfo;
    storeSessionInfo(sessionInfo: SessionInfo): void;
    updateSessionId(id: string | number): void;
    sessionExpired(): void;
    isLoggedIn(): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<LoginStorageService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<LoginStorageService>;
}
