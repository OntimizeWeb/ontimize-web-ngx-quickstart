import * as i0 from "@angular/core";
import * as i1 from "./o-card-menu-layout.component";
import * as i2 from "@angular/common";
import * as i3 from "../../components/card-menu-item/o-card-menu-item.module";
import * as i4 from "../../shared/shared.module";
export declare class OCardMenuLayoutModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OCardMenuLayoutModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OCardMenuLayoutModule, [typeof i1.OCardMenuLayoutComponent], [typeof i2.CommonModule, typeof i3.OCardMenuItemModule, typeof i4.OSharedModule], [typeof i1.OCardMenuLayoutComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OCardMenuLayoutModule>;
}
