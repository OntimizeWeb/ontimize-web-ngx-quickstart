export declare abstract class OAppLayoutBase {
    abstract useFlagIcons: boolean;
    abstract tooltipDisplayMode: string;
}
