import { OnChanges } from '@angular/core';
import { OFormLayoutManagerComponent } from '../../o-form-layout-manager.component';
import { OFormLayoutSidenavOptions } from '../../../../types/form-layout-sidenav-options.type';
import * as i0 from "@angular/core";
export declare class OFormLayoutSidenavOptionsDirective implements OnChanges {
    protected formLayoutManager: OFormLayoutManagerComponent;
    constructor(formLayoutManager: OFormLayoutManagerComponent);
    ngOnChanges(): void;
    width: string;
    position: 'start' | 'end';
    labelColumns: string;
    separator: string;
    getOptions(): OFormLayoutSidenavOptions;
    static ɵfac: i0.ɵɵFactoryDeclaration<OFormLayoutSidenavOptionsDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<OFormLayoutSidenavOptionsDirective, "o-form-layout-sidenav-options, o-form-layout-manager[mode=\"sidenav\"]", never, { "width": "width"; "position": "position"; "labelColumns": "label-columns"; "separator": "separator"; }, {}, never, never, false, never>;
}
