import { Injector } from '@angular/core';
import { Router } from '@angular/router';
import { NavigationService, ONavigationItem } from '../../../services/navigation.service';
import * as i0 from "@angular/core";
export declare class Error403Component {
    protected injector: Injector;
    protected router: Router;
    protected navigationService: NavigationService;
    protected lastPageData: ONavigationItem;
    constructor(injector: Injector);
    onNavigateBackClick(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<Error403Component, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<Error403Component, "o-error-403", never, {}, {}, never, never, false, never>;
}
