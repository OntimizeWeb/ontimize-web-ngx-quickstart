import { ElementRef, OnInit, Renderer2 } from '@angular/core';
import { ControlValueAccessor } from '@angular/forms';
import * as i0 from "@angular/core";
export declare class InputRegulateDirective implements ControlValueAccessor, OnInit {
    private readonly elementRef;
    private readonly renderer;
    private onChange;
    private onTouched;
    private value;
    oInputRegulatePattern: string;
    regExpattern: RegExp;
    constructor(elementRef: ElementRef, renderer: Renderer2);
    ngOnInit(): void;
    onInputChange(value: string): void;
    onBlur(): void;
    private updateTextInput;
    registerOnChange(fn: any): void;
    registerOnTouched(fn: any): void;
    setDisabledState(isDisabled: boolean): void;
    writeValue(value: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<InputRegulateDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<InputRegulateDirective, "[oInputRegulate]", never, { "oInputRegulatePattern": "oInputRegulatePattern"; }, {}, never, never, false, never>;
}
