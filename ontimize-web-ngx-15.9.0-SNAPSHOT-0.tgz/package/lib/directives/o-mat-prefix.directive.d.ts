import * as i0 from "@angular/core";
export declare class OMatPrefix {
    static ɵfac: i0.ɵɵFactoryDeclaration<OMatPrefix, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<OMatPrefix, "[oMatPrefix]", never, {}, {}, never, never, false, never>;
}
