import { PipeTransform } from '@angular/core';
import * as i0 from "@angular/core";
export declare class IsEmptyValuePipe implements PipeTransform {
    transform(value: any): unknown;
    static ɵfac: i0.ɵɵFactoryDeclaration<IsEmptyValuePipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<IsEmptyValuePipe, "isEmptyValue", false>;
}
