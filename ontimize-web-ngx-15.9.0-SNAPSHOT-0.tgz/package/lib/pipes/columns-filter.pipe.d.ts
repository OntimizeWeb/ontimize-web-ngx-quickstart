import { PipeTransform } from '@angular/core';
import * as i0 from "@angular/core";
export declare class ColumnsFilterPipe implements PipeTransform {
    filterValue: string;
    filterColumns: Array<string>;
    transform(value: Array<any>, args: any): any;
    _isBlank(value: string): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<ColumnsFilterPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<ColumnsFilterPipe, "columnsfilter", false>;
}
