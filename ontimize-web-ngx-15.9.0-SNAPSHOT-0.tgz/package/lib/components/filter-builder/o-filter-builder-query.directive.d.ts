import { OFilterBuilderComponent } from './o-filter-builder.component';
import * as i0 from "@angular/core";
export declare class OFilterBuilderQueryDirective {
    protected _filterBuilder: OFilterBuilderComponent;
    constructor(filterBuilder: OFilterBuilderComponent);
    onClick(e?: Event): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OFilterBuilderQueryDirective, [{ optional: true; }]>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<OFilterBuilderQueryDirective, "[oFilterBuilderQuery]", ["oFilterBuilderQuery"], { "_filterBuilder": "oFilterBuilderQuery"; }, {}, never, never, false, never>;
}
