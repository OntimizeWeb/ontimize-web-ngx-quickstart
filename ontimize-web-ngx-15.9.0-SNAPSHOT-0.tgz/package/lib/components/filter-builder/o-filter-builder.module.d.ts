import * as i0 from "@angular/core";
import * as i1 from "./o-filter-builder.component";
import * as i2 from "./o-filter-builder-clear.directive";
import * as i3 from "./o-filter-builder-query.directive";
import * as i4 from "./filter-builder-menu/filter-builder-menu.component";
import * as i5 from "../../shared/shared.module";
import * as i6 from "@angular/common";
export declare class OFilterBuilderModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OFilterBuilderModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OFilterBuilderModule, [typeof i1.OFilterBuilderComponent, typeof i2.OFilterBuilderClearDirective, typeof i3.OFilterBuilderQueryDirective, typeof i4.OFilterBuilderMenuComponent], [typeof i5.OSharedModule, typeof i6.CommonModule], [typeof i1.OFilterBuilderComponent, typeof i2.OFilterBuilderClearDirective, typeof i3.OFilterBuilderQueryDirective, typeof i4.OFilterBuilderMenuComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OFilterBuilderModule>;
}
