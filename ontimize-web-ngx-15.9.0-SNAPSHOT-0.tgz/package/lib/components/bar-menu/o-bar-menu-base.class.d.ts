import { PermissionsService } from "../../services/permissions/permissions.service";
import { MenuRootItem } from '../../types/menu-root-item.type';
import * as i0 from "@angular/core";
export declare abstract class OBarMenuBase {
    abstract getPermissionsService(): PermissionsService;
    abstract collapseAll(): any;
    abstract ngOnInit(): void;
    abstract setDOMTitle(): void;
    abstract get menuTitle(): string;
    abstract set menuTitle(val: string);
    abstract get tooltip(): string;
    abstract set tooltip(val: string);
    abstract get id(): string;
    abstract set id(val: string);
    abstract get menuItems(): MenuRootItem[];
    static ɵfac: i0.ɵɵFactoryDeclaration<OBarMenuBase, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OBarMenuBase>;
}
