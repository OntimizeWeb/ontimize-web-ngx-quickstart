import * as i0 from "@angular/core";
import * as i1 from "./o-bar-menu.component";
import * as i2 from "./menu-item/o-bar-menu-item.component";
import * as i3 from "./menu-group/o-bar-menu-group.component";
import * as i4 from "./locale-menu-item/o-locale-bar-menu-item.component";
import * as i5 from "./menu-separator/o-bar-menu-separator.component";
import * as i6 from "./menu-nested/o-bar-menu-nested.component";
import * as i7 from "@angular/common";
import * as i8 from "../../shared/shared.module";
import * as i9 from "@angular/router";
export declare class OBarMenuModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OBarMenuModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OBarMenuModule, [typeof i1.OBarMenuComponent, typeof i2.OBarMenuItemComponent, typeof i3.OBarMenuGroupComponent, typeof i4.OLocaleBarMenuItemComponent, typeof i5.OBarMenuSeparatorComponent, typeof i6.OBarMenuNestedComponent], [typeof i7.CommonModule, typeof i8.OSharedModule, typeof i9.RouterModule], [typeof i1.OBarMenuComponent, typeof i2.OBarMenuItemComponent, typeof i3.OBarMenuGroupComponent, typeof i4.OLocaleBarMenuItemComponent, typeof i5.OBarMenuSeparatorComponent, typeof i6.OBarMenuNestedComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OBarMenuModule>;
}
