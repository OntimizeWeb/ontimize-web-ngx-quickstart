import { Injector } from '@angular/core';
import { OContextMenuComponent } from './o-context-menu.component';
import * as i0 from "@angular/core";
export declare const DEFAULT_CONTEXT_MENU_DIRECTIVE_INPUTS: string[];
export declare class OContextMenuDirective {
    protected injector: Injector;
    oContextMenu: OContextMenuComponent;
    oContextMenuData: any;
    constructor(injector: Injector);
    onRightClick(event: MouseEvent): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OContextMenuDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<OContextMenuDirective, "[oContextMenu]", never, { "oContextMenu": "oContextMenu"; "oContextMenuData": "oContextMenuData"; }, {}, never, never, false, never>;
}
