import { Overlay, OverlayRef, ScrollStrategyOptions } from '@angular/cdk/overlay';
import { ChangeDetectorRef, ElementRef, OnDestroy, Renderer2 } from '@angular/core';
import { Subject, Subscription } from 'rxjs';
import { IOContextMenuClickEvent, IOContextMenuContext } from '../../interfaces/o-context-menu.interface';
import { OContextMenuOverlayService } from './o-context-menu-overlay.service';
import * as i0 from "@angular/core";
export declare class OContextMenuService implements OnDestroy {
    private overlay;
    private scrollStrategy;
    private cd;
    private overlayService;
    private renderer;
    showContextMenu: Subject<IOContextMenuClickEvent>;
    closeContextMenu: Subject<void>;
    protected fakeElement: ElementRef;
    protected subscription: Subscription;
    constructor(overlay: Overlay, scrollStrategy: ScrollStrategyOptions, cd: ChangeDetectorRef, overlayService: OContextMenuOverlayService, renderer: Renderer2);
    ngOnDestroy(): void;
    openContextMenu(context: IOContextMenuContext): void;
    protected destroyOverlays(): void;
    protected createOverlay(context: IOContextMenuContext): void;
    protected attachContextMenu(overlay: OverlayRef, context: IOContextMenuContext): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OContextMenuService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OContextMenuService>;
}
