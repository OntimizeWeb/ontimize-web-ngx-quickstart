import { Injector, TemplateRef } from '@angular/core';
import { ValidatorFn } from '@angular/forms';
import { OTableCellEditorIntegerComponent } from '../integer/o-table-cell-editor-integer.component';
import * as i0 from "@angular/core";
export declare class OTableCellEditorRealComponent extends OTableCellEditorIntegerComponent {
    protected injector: Injector;
    templateref: TemplateRef<any>;
    min: number;
    max: number;
    step: number;
    constructor(injector: Injector);
    getCellData(): number;
    resolveValidators(): ValidatorFn[];
    static ɵfac: i0.ɵɵFactoryDeclaration<OTableCellEditorRealComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OTableCellEditorRealComponent, "o-table-cell-editor-real", never, {}, {}, never, never, false, never>;
}
