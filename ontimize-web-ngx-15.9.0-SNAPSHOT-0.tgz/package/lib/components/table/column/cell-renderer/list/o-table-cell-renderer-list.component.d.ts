import { Injector, TemplateRef } from '@angular/core';
import { OBaseTableCellRenderer } from '../o-base-table-cell-renderer.class';
import * as i0 from "@angular/core";
export declare const O_TABLE_CELL_RENDERER_LIST: string[];
export declare class OTableCellRendererListComponent extends OBaseTableCellRenderer {
    protected injector: Injector;
    templateref: TemplateRef<any>;
    constructor(injector: Injector);
    initialize(): void;
    getCellData(cellvalue: any): string;
    getTooltip(cellValue: any): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<OTableCellRendererListComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OTableCellRendererListComponent, "o-table-cell-renderer-list", never, {}, {}, never, never, false, never>;
}
