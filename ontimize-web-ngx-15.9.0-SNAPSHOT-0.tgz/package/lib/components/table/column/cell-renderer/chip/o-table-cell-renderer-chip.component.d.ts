import { Injector, OnInit, TemplateRef } from '@angular/core';
import { OBaseTableCellRenderer } from '../o-base-table-cell-renderer.class';
import * as i0 from "@angular/core";
export declare const DEFAULT_INPUTS_O_TABLE_CELL_RENDERER_CHIP: string[];
export declare class OTableCellRendererChipComponent extends OBaseTableCellRenderer implements OnInit {
    protected injector: Injector;
    templateref: TemplateRef<any>;
    iconPosition: string;
    svgIcon: string;
    icon: string;
    translate: boolean;
    constructor(injector: Injector);
    initialize(): void;
    getCellData(value: any): any;
    isArray(value: any): boolean;
    isIconPositionLeft(): boolean;
    isIconPositionRight(): boolean;
    isSvgIconPositionRight(): boolean;
    isSvgIconPositionLeft(): boolean;
    shouldTranslate(): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<OTableCellRendererChipComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OTableCellRendererChipComponent, "o-table-cell-renderer-chip", never, { "icon": "icon"; "svgIcon": "svg-icon"; "iconPosition": "icon-position"; "translate": "boolean"; }, {}, never, never, false, never>;
}
