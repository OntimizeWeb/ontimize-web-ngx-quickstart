import { Injector, OnInit, TemplateRef } from '@angular/core';
import { IMomentPipeArgument, OMomentPipe } from '../../../../../pipes/o-moment.pipe';
import { OBaseTableCellRenderer } from '../o-base-table-cell-renderer.class';
import * as i0 from "@angular/core";
export declare const DEFAULT_INPUTS_O_TABLE_CELL_RENDERER_TIME: string[];
export declare class OTableCellRendererTimeComponent extends OBaseTableCellRenderer implements OnInit {
    protected injector: Injector;
    protected componentPipe: OMomentPipe;
    protected pipeArguments: IMomentPipeArgument;
    protected _format: string;
    protected locale: string;
    templateref: TemplateRef<any>;
    constructor(injector: Injector);
    set format(value: string);
    setComponentPipe(): void;
    initialize(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OTableCellRendererTimeComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OTableCellRendererTimeComponent, "o-table-cell-renderer-time", never, { "format": "format"; }, {}, never, never, false, never>;
}
