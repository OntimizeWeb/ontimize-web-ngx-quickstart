import { Subject } from 'rxjs';
import * as i0 from "@angular/core";
export declare class OTableExportButtonService {
    export$: Subject<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<OTableExportButtonService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OTableExportButtonService>;
}
