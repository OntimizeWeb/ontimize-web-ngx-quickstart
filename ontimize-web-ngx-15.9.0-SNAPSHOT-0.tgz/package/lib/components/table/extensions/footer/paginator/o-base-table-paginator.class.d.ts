import { OTablePaginator } from '../../../../../interfaces/o-table-paginator.interface';
export declare class OBaseTablePaginator implements OTablePaginator {
    protected _pageIndex: number;
    protected _pageSize: number;
    protected _pageSizeOptions: number[];
    showFirstLastButtons: boolean;
    get pageLenght(): number;
    set pageLenght(value: number);
    get pageIndex(): number;
    set pageIndex(value: number);
    get pageSizeOptions(): number[];
    set pageSizeOptions(value: number[]);
    get pageSize(): number;
    set pageSize(value: number);
    isShowingAllRows(selectedLength: any): boolean;
}
