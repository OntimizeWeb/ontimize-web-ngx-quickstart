import { OTableOptions } from '../../../interfaces/o-table-options.interface';
import { OColumn } from '../column/o-column.class';
export declare class DefaultOTableOptions implements OTableOptions {
    columns: Array<OColumn>;
    filter: boolean;
    filterCaseSensitive: boolean;
    protected _visibleColumns: Array<any>;
    protected _selectColumn: OColumn;
    protected _expandableColumn: OColumn;
    constructor();
    get visibleColumns(): Array<any>;
    set visibleColumns(arg: Array<any>);
    get columnsInsertables(): Array<string>;
    get selectColumn(): OColumn;
    set selectColumn(val: OColumn);
    get expandableColumn(): OColumn;
    set expandableColumn(val: OColumn);
}
