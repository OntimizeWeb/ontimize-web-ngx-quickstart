import { CdkColumnDef } from '@angular/cdk/table';
import { ChangeDetectorRef, ElementRef, Injector } from '@angular/core';
import { MatSortHeader, MatSortHeaderIntl } from '@angular/material/sort';
import { FocusMonitor } from '@angular/cdk/a11y';
import { OMatSort } from './o-mat-sort';
import * as i0 from "@angular/core";
export declare class OMatSortHeader extends MatSortHeader {
    _intl: MatSortHeaderIntl;
    _sort: OMatSort;
    _cdkColumnDef: CdkColumnDef;
    injector: Injector;
    private readonly loadingService;
    constructor(_intl: MatSortHeaderIntl, changeDetectorRef: ChangeDetectorRef, _sort: OMatSort, _cdkColumnDef: CdkColumnDef, _focusMonitor: FocusMonitor, _elementRef: ElementRef<HTMLElement>, injector: Injector);
    _handleClick(): void;
    _isSorted(): boolean;
    _updateArrowDirection(): void;
    refresh(): void;
    getSortIndicatorNumbered(): string;
    getSortIndicatorNumberedClass(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<OMatSortHeader, [null, null, { optional: true; }, { optional: true; }, null, null, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OMatSortHeader, "[o-mat-sort-header]", ["oMatSortHeader"], { "disabled": "disabled"; }, {}, never, ["*"], false, never>;
}
