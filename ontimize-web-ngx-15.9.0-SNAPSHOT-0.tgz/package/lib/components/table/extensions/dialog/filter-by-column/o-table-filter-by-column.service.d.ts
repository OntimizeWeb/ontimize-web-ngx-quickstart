import { Injector } from '@angular/core';
import { OColumnValueFilter } from '../../../../../types/table/o-column-value-filter.type';
import { TableFilterByColumnData } from '../../../../../types/table/o-table-filter-by-column-data.type';
import { OColumn } from '../../../column/o-column.class';
import { Observable } from 'rxjs';
import { OTableBase } from '../../../o-table-base.class';
import { OFilterColumn } from '../../header/table-columns-filter/columns/o-table-columns-filter-column.component';
import * as i0 from "@angular/core";
export declare class OTableFilterByColumnService {
    constructor();
    getColumnDataUsingRenderer(column: OColumn, tableData: any[], visibleColumns: string[], separator: string): any[];
    parseListData(filter: OColumnValueFilter, column: OColumn, tableData: any[], isPageable: boolean, filterColumnDefinition: OFilterColumn): TableFilterByColumnData[];
    applySelectedValuesToFilter(column: OColumn, tableData: any[], filter: OColumnValueFilter, selectedValues: TableFilterByColumnData[], filterByColumnDefinition: OFilterColumn, isPageable: boolean, getComponentFilterFn: () => any): void;
    getDataForColumnFilter(injector: Injector, table: OTableBase, column: OColumn, filterColumnDefinition: OFilterColumn): Observable<any[]>;
    configureService(injector: Injector, filterColumnDefinition: OFilterColumn, tableEntity: OTableBase): any;
    initializeColumnFilterData(filter: OColumnValueFilter, column: OColumn, tableData: any[], isPageable: boolean, filterColumnDefinition: OFilterColumn): TableFilterByColumnData[];
    static ɵfac: i0.ɵɵFactoryDeclaration<OTableFilterByColumnService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OTableFilterByColumnService>;
}
