import { ElementRef, EventEmitter, Injector, OnInit } from '@angular/core';
import { OTableButton } from '../../../../../interfaces/o-table-button.interface';
import { OTableBase } from '../../../o-table-base.class';
import * as i0 from "@angular/core";
export declare const DEFAULT_INPUTS_O_TABLE_BUTTON: string[];
export declare const DEFAULT_OUTPUTS_O_TABLE_BUTTON: string[];
export declare class OTableButtonComponent implements OTableButton, OnInit {
    protected injector: Injector;
    elRef: ElementRef;
    protected _table: OTableBase;
    onClick: EventEmitter<object>;
    oattr: string;
    enabled: boolean;
    icon: string;
    svgIcon: string;
    olabel: string;
    iconPosition: string;
    constructor(injector: Injector, elRef: ElementRef, _table: OTableBase);
    ngOnInit(): void;
    innerOnClick(event: any): void;
    isReadOnly(): boolean;
    isIconPositionLeft(): boolean;
    get table(): OTableBase;
    static ɵfac: i0.ɵɵFactoryDeclaration<OTableButtonComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OTableButtonComponent, "o-table-button", never, { "oattr": "attr"; "enabled": "enabled"; "icon": "icon"; "svgIcon": "svg-icon"; "iconPosition": "icon-position"; "olabel": "label"; }, { "onClick": "onClick"; }, never, never, false, never>;
}
