import { OnInit } from '@angular/core';
import * as i0 from "@angular/core";
export type OFilterColumn = {
    attr: string;
    sort: 'asc' | 'desc' | '';
    startView: 'month' | 'year' | 'multi-year' | '';
    queryMethod?: string;
    filterValuesInData?: 'current-page' | 'all-data';
    service?: string;
    entity?: string;
    serviceType?: string;
    separator?: string;
    visibleColumns?: string[];
    filterLocked?: boolean;
    filterLockedMessage?: string;
};
export declare const DEFAULT_INPUTS_O_TABLE_COLUMN_FILTER_COLUMN: string[];
export declare class OTableColumnsFilterColumnComponent implements OnInit {
    attr: string;
    sort: 'asc' | 'desc' | '';
    startView: 'month' | 'year' | 'multi-year' | '';
    queryMethod: string;
    filterValuesInData: 'current-page' | 'all-data';
    filterLocked: boolean;
    filterLockedMessage: string;
    service: string;
    serviceType: string;
    entity: string;
    visibleColsArray: string[];
    visibleColumns: string;
    separator: string;
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OTableColumnsFilterColumnComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OTableColumnsFilterColumnComponent, "o-table-columns-filter-column", never, { "attr": "attr"; "sort": "sort"; "startView": "start-view"; "queryMethod": "query-method"; "filterValuesInData": "filter-values-in-data"; "filterLocked": "filter-locked"; "filterLockedMessage": "filter-locked-message"; "service": "service"; "serviceType": "service-type"; "entity": "entity"; "visibleColumns": "visible-columns"; "separator": "separator"; }, {}, never, never, false, never>;
}
