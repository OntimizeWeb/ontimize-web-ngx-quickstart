export declare class OTableExportConfiguration {
    service: string;
    columns: [];
    serviceType: string;
    visibleButtons: string;
    options?: any;
}
