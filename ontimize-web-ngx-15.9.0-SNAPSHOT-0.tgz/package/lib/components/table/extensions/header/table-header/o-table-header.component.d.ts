import type { OColumn } from "../../../column/o-column.class";
import { OTableBase } from "../../../o-table-base.class";
import { OMatSortHeader } from "../../sort/o-mat-sort-header";
import type { OTableHeaderColumnFilterIconComponent } from "../table-header-column-filter-icon/o-table-header-column-filter-icon.component";
import { OColumnValueFilter } from "../../../../../types/table/o-column-value-filter.type";
import * as i0 from "@angular/core";
export declare const DEFAULT_INPUTS_O_TABLE_HEADER: string[];
export declare class OTableHeaderComponent {
    protected table: OTableBase;
    column: OColumn;
    columnFilters: OColumnValueFilter[];
    resizable: boolean;
    protected _columnFilterIcon: OTableHeaderColumnFilterIconComponent;
    set columnFilterIcon(value: OTableHeaderColumnFilterIconComponent);
    matSortHeader: OMatSortHeader;
    constructor(table: OTableBase);
    isModeColumnFilterable(column: OColumn): boolean;
    setFilterIconHintVisible(visible: boolean): void;
    ngAfterViewInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OTableHeaderComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OTableHeaderComponent, "o-table-header", never, { "column": "column"; "columnFilters": "column-filters"; }, {}, never, never, false, never>;
}
