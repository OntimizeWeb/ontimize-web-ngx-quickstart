import * as i0 from "@angular/core";
import * as i1 from "./o-form.component";
import * as i2 from "@angular/common";
import * as i3 from "./toolbar/o-form-toolbar.module";
import * as i4 from "../../shared/shared.module";
export declare class OFormModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OFormModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OFormModule, [typeof i1.OFormComponent], [typeof i2.CommonModule, typeof i3.OFormToolbarModule, typeof i4.OSharedModule], [typeof i1.OFormComponent, typeof i3.OFormToolbarModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OFormModule>;
}
