import { MatSelectChange } from "@angular/material/select";
import { OGroupedColumnTypes } from "../../../../types/o-grouped-column-types.type";
import * as i0 from "@angular/core";
export declare const DEFAULT_DUAL_LIST_SELECTOR_DATE_ITEM: string[];
export declare class ODualListSelectorDateItemComponent {
    dateTypes: {
        value: string;
        viewValue: string;
    }[];
    item: string;
    groupedDateColumns: OGroupedColumnTypes[];
    onSelectionChange(event: MatSelectChange, itemSelected: any): void;
    getSelectValue(): string;
    getViewValue(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<ODualListSelectorDateItemComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ODualListSelectorDateItemComponent, "o-dual-list-selector-date-item", never, { "item": "item"; "groupedDateColumns": "grouped-date-columns"; }, {}, never, never, false, never>;
}
