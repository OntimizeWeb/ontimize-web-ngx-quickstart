import * as i0 from "@angular/core";
import * as i1 from "./o-checkbox.component";
import * as i2 from "@angular/common";
import * as i3 from "../../../shared/shared.module";
export declare class OCheckboxModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OCheckboxModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OCheckboxModule, [typeof i1.OCheckboxComponent], [typeof i2.CommonModule, typeof i3.OSharedModule], [typeof i1.OCheckboxComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OCheckboxModule>;
}
