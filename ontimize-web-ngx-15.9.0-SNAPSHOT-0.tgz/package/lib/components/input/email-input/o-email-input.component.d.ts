import { ElementRef, Injector, OnInit } from '@angular/core';
import { ValidatorFn } from '@angular/forms';
import { OFormComponent } from '../../form/o-form.component';
import { OTextInputComponent } from '../text-input/o-text-input.component';
import * as i0 from "@angular/core";
export declare class OEmailInputComponent extends OTextInputComponent implements OnInit {
    constructor(form: OFormComponent, elRef: ElementRef, injector: Injector);
    resolveValidators(): ValidatorFn[];
    static ɵfac: i0.ɵɵFactoryDeclaration<OEmailInputComponent, [{ optional: true; }, null, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OEmailInputComponent, "o-email-input", never, {}, {}, never, never, false, never>;
}
