import * as i0 from "@angular/core";
import * as i1 from "./o-email-input.component";
import * as i2 from "../../../shared/shared.module";
import * as i3 from "@angular/common";
import * as i4 from "../text-input/o-text-input.module";
export declare class OEmailInputModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OEmailInputModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OEmailInputModule, [typeof i1.OEmailInputComponent], [typeof i2.OSharedModule, typeof i3.CommonModule, typeof i4.OTextInputModule], [typeof i1.OEmailInputComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OEmailInputModule>;
}
