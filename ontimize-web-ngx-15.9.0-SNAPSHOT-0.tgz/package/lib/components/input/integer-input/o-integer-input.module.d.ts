import * as i0 from "@angular/core";
import * as i1 from "./o-integer-input.component";
import * as i2 from "@angular/common";
import * as i3 from "../../../shared/shared.module";
import * as i4 from "../text-input/o-text-input.module";
export declare class OIntegerInputModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OIntegerInputModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OIntegerInputModule, [typeof i1.OIntegerInputComponent], [typeof i2.CommonModule, typeof i3.OSharedModule, typeof i4.OTextInputModule], [typeof i1.OIntegerInputComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OIntegerInputModule>;
}
