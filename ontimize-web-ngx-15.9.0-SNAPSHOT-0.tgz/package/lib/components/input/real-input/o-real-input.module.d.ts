import * as i0 from "@angular/core";
import * as i1 from "./o-real-input.component";
import * as i2 from "@angular/common";
import * as i3 from "../../../shared/shared.module";
import * as i4 from "../integer-input/o-integer-input.module";
export declare class ORealInputModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ORealInputModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ORealInputModule, [typeof i1.ORealInputComponent], [typeof i2.CommonModule, typeof i3.OSharedModule, typeof i4.OIntegerInputModule], [typeof i1.ORealInputComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ORealInputModule>;
}
