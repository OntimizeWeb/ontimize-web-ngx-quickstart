import * as i0 from "@angular/core";
import * as i1 from "./o-phone-input.component";
import * as i2 from "@angular/common";
import * as i3 from "../../../shared/shared.module";
export declare class OPhoneInputModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OPhoneInputModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OPhoneInputModule, [typeof i1.OPhoneInputComponent], [typeof i2.CommonModule, typeof i3.OSharedModule], [typeof i1.OPhoneInputComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OPhoneInputModule>;
}
