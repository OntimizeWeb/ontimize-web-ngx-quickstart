import * as i0 from "@angular/core";
import * as i1 from "./o-percent-input.component";
import * as i2 from "@angular/common";
import * as i3 from "../../../shared/shared.module";
import * as i4 from "../real-input/o-real-input.module";
export declare class OPercentInputModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OPercentInputModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OPercentInputModule, [typeof i1.OPercentInputComponent], [typeof i2.CommonModule, typeof i3.OSharedModule, typeof i4.ORealInputModule], [typeof i1.OPercentInputComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OPercentInputModule>;
}
