import * as i0 from "@angular/core";
import * as i1 from "./o-hour-input.component";
import * as i2 from "./o-hour-input.directive";
import * as i3 from "../../../shared/shared.module";
import * as i4 from "@angular/common";
import * as i5 from "ngx-material-timepicker";
export declare class OHourInputModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OHourInputModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OHourInputModule, [typeof i1.OHourInputComponent, typeof i2.OHourTimepickerDirective], [typeof i3.OSharedModule, typeof i4.CommonModule, typeof i5.NgxMaterialTimepickerModule], [typeof i1.OHourInputComponent, typeof i2.OHourTimepickerDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OHourInputModule>;
}
