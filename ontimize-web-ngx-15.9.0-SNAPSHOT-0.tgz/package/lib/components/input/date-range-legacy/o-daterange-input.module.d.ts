import * as i0 from "@angular/core";
import * as i1 from "./o-daterange-picker.component";
import * as i2 from "./o-daterange-input.component";
import * as i3 from "./o-daterange-input.directive";
import * as i4 from "@angular/common";
import * as i5 from "../../../shared/shared.module";
export declare class ODateRangeLegacyInputModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ODateRangeLegacyInputModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ODateRangeLegacyInputModule, [typeof i1.DaterangepickerComponent, typeof i2.ODateRangeLegacyInputComponent, typeof i3.ODaterangepickerDirective], [typeof i4.CommonModule, typeof i5.OSharedModule], [typeof i2.ODateRangeLegacyInputComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ODateRangeLegacyInputModule>;
}
