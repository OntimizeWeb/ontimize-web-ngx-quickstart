import * as i0 from "@angular/core";
import * as i1 from "./o-html-input.component";
import * as i2 from "../../material/ckeditor/ck-editor.module";
import * as i3 from "@angular/common";
import * as i4 from "../../../shared/shared.module";
export declare class OHTMLInputModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OHTMLInputModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OHTMLInputModule, [typeof i1.OHTMLInputComponent], [typeof i2.CKEditorModule, typeof i3.CommonModule, typeof i4.OSharedModule], [typeof i1.OHTMLInputComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OHTMLInputModule>;
}
