import * as i0 from "@angular/core";
import * as i1 from "./o-search-input.component";
import * as i2 from "@angular/common";
import * as i3 from "../../../shared/shared.module";
export declare class OSearchInputModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OSearchInputModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OSearchInputModule, [typeof i1.OSearchInputComponent], [typeof i2.CommonModule, typeof i3.OSharedModule], [typeof i1.OSearchInputComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OSearchInputModule>;
}
