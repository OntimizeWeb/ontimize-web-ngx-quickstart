import { ElementRef, Injector } from '@angular/core';
import { OFormComponent } from '../form/o-form.component';
import { OFormDataComponent } from '../o-form-data-component.class';
import * as i0 from "@angular/core";
export declare const DEFAULT_INPUTS_O_BOOLEAN_FORM_DATA: string[];
export declare class OBooleanFormDataComponent extends OFormDataComponent {
    trueValue: any;
    falseValue: any;
    booleanType: 'number' | 'boolean' | 'string';
    constructor(form: OFormComponent, elRef: ElementRef, injector: Injector);
    initialize(): void;
    ensureOFormValue(data: any): void;
    parseValueByType(value: any): any;
    protected parseStringInputs(): void;
    protected parseNumberInputs(): void;
    protected parseInputs(): void;
    onClickBlocker(evt: Event): void;
    getValue(): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<OBooleanFormDataComponent, [{ optional: true; }, null, null]>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<OBooleanFormDataComponent, never, never, { "trueValue": "true-value"; "falseValue": "false-value"; "booleanType": "boolean-type"; }, {}, never, never, false, never>;
}
