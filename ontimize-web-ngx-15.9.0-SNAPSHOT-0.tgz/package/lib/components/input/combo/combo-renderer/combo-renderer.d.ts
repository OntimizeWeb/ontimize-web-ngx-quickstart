import { OComboRendererBooleanComponent } from './boolean/o-combo-renderer-boolean.component';
import { OComboRendererCurrencyComponent } from './currency/o-combo-renderer-currency.component';
import { OComboRendererDateComponent } from './date/o-combo-renderer-date.component';
import { OComboRendererIconComponent } from './icon/o-combo-renderer-icon.component';
import { OComboRendererIntegerComponent } from './integer/o-combo-renderer-integer.component';
import { OComboRendererPercentageComponent } from './percentage/o-combo-renderer-percentage.component';
import { OComboRendererRealComponent } from './real/o-combo-renderer-real.component';
export declare const O_COMBO_RENDERERS: (typeof OComboRendererBooleanComponent | typeof OComboRendererIntegerComponent | typeof OComboRendererCurrencyComponent | typeof OComboRendererDateComponent | typeof OComboRendererIconComponent)[];
export declare const renderersMapping: {
    integer: typeof OComboRendererIntegerComponent;
    real: typeof OComboRendererRealComponent;
    currency: typeof OComboRendererCurrencyComponent;
    boolean: typeof OComboRendererBooleanComponent;
    date: typeof OComboRendererDateComponent;
    percentage: typeof OComboRendererPercentageComponent;
    icon: typeof OComboRendererIconComponent;
};
