import { Injector, OnInit, TemplateRef } from '@angular/core';
import { IRealPipeArgument, ORealPipe } from '../../../../../pipes/o-real.pipe';
import { NumberService } from '../../../../../services/number.service';
import { OComboRendererIntegerComponent } from '../integer/o-combo-renderer-integer.component';
import * as i0 from "@angular/core";
export declare const DEFAULT_INPUTS_O_COMBO_RENDERER_REAL: string[];
export declare class OComboRendererRealComponent extends OComboRendererIntegerComponent implements OnInit {
    protected injector: Injector;
    minDecimalDigits: number;
    maxDecimalDigits: number;
    protected decimalSeparator: string;
    protected numberService: NumberService;
    protected componentPipe: ORealPipe;
    protected pipeArguments: IRealPipeArgument;
    templateref: TemplateRef<any>;
    constructor(injector: Injector);
    setComponentPipe(): void;
    initialize(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OComboRendererRealComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OComboRendererRealComponent, "o-combo-renderer-real", never, { "decimalSeparator": "decimal-separator"; "minDecimalDigits": "min-decimal-digits"; "maxDecimalDigits": "max-decimal-digits"; }, {}, never, never, false, never>;
}
