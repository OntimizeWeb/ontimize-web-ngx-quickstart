import * as i0 from "@angular/core";
import * as i1 from "./o-app-sidenav.component";
import * as i2 from "./menu-group/o-app-sidenav-menu-group.component";
import * as i3 from "./image/o-app-sidenav-image.component";
import * as i4 from "./menu-item/o-app-sidenav-menu-item.component";
import * as i5 from "@angular/common";
import * as i6 from "../../shared/shared.module";
import * as i7 from "@angular/router";
import * as i8 from "../language-selector/o-language-selector.module";
export declare class OAppSidenavModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OAppSidenavModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OAppSidenavModule, [typeof i1.OAppSidenavComponent, typeof i2.OAppSidenavMenuGroupComponent, typeof i3.OAppSidenavImageComponent, typeof i4.OAppSidenavMenuItemComponent], [typeof i5.CommonModule, typeof i6.OSharedModule, typeof i7.RouterModule, typeof i8.OLanguageSelectorModule], [typeof i1.OAppSidenavComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OAppSidenavModule>;
}
