import * as i0 from "@angular/core";
import * as i1 from "./o-data-toolbar.component";
import * as i2 from "@angular/common";
import * as i3 from "../../shared/shared.module";
import * as i4 from "@angular/router";
export declare class ODataToolbarModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ODataToolbarModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ODataToolbarModule, [typeof i1.ODataToolbarComponent], [typeof i2.CommonModule, typeof i3.OSharedModule, typeof i4.RouterModule], [typeof i1.ODataToolbarComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ODataToolbarModule>;
}
