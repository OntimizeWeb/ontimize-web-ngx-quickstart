import * as i0 from "@angular/core";
import * as i1 from "./o-image.component";
import * as i2 from "./fullscreen/fullscreen-dialog.component";
import * as i3 from "@angular/common";
import * as i4 from "../../shared/shared.module";
export declare class OImageModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OImageModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OImageModule, [typeof i1.OImageComponent, typeof i2.OFullScreenDialogComponent], [typeof i3.CommonModule, typeof i4.OSharedModule], [typeof i1.OImageComponent, typeof i2.OFullScreenDialogComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OImageModule>;
}
