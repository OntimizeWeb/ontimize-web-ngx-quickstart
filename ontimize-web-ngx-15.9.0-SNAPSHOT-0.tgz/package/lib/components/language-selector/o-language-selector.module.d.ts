import * as i0 from "@angular/core";
import * as i1 from "./o-language-selector.component";
import * as i2 from "../../shared/shared.module";
import * as i3 from "@angular/common";
export declare class OLanguageSelectorModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OLanguageSelectorModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OLanguageSelectorModule, [typeof i1.OLanguageSelectorComponent], [typeof i2.OSharedModule, typeof i3.CommonModule], [typeof i1.OLanguageSelectorComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OLanguageSelectorModule>;
}
