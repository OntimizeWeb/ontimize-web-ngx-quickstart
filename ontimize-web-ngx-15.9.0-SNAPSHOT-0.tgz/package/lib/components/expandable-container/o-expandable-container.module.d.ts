import * as i0 from "@angular/core";
import * as i1 from "./o-expandable-container.component";
import * as i2 from "@angular/common";
import * as i3 from "../../shared/shared.module";
export declare class OExpandableContainerModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OExpandableContainerModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OExpandableContainerModule, [typeof i1.OExpandableContainerComponent], [typeof i2.CommonModule, typeof i3.OSharedModule], [typeof i1.OExpandableContainerComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OExpandableContainerModule>;
}
