import { AfterViewInit, ViewContainerRef } from '@angular/core';
import { OFormBase } from '../form/o-form-base.class';
import { OFormLayoutManagerBase } from '../../layouts/form-layout/o-form-layout-manager-base.class';
import * as i0 from "@angular/core";
export declare const DEFAULT_INPUTS_O_FORM_CONTAINER: string[];
export declare class OFormContainerComponent implements AfterViewInit {
    breadContainer: ViewContainerRef;
    breadcrumb: boolean;
    breadcrumbLabelColumns: string;
    breadcrumbSeparator: string;
    protected form: OFormBase;
    protected formMananger: OFormLayoutManagerBase;
    ngAfterViewInit(): void;
    setForm(form: OFormBase): void;
    createBreadcrumb(container: ViewContainerRef): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OFormContainerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OFormContainerComponent, "o-form-container", never, { "breadcrumb": "breadcrumb"; "breadcrumbSeparator": "breadcrumb-separator"; "breadcrumbLabelColumns": "breadcrumb-label-columns"; "form": "form"; }, {}, never, ["*"], false, never>;
}
