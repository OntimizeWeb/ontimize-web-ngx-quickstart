import type { OUserInfoBase } from "../user-info/o-user-info-base.class";
export declare abstract class OAppHeaderBase {
    abstract userInfo: OUserInfoBase;
}
