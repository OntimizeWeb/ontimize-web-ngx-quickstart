export declare abstract class ListItem {
    abstract getItemData(): any;
    abstract setItemData(data: any): void;
}
