export declare function StringConverter(value: any): any;
export declare function BooleanConverter(value: any): any;
export declare function NumberConverter(value: any): number;
export declare function BooleanInputConverter(): (target: unknown, propertyKey: PropertyKey) => any;
export declare function NumberInputConverter(): (target: unknown, propertyKey: PropertyKey) => any;
