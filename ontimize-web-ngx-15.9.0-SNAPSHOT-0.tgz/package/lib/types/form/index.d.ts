export * from './o-form-global-config.type';
