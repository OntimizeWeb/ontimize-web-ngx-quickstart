import { InjectionToken } from "@angular/core";
export type OGlobalConfig = {
    storeState: boolean;
};
export declare const O_GLOBAL_CONFIG: InjectionToken<OGlobalConfig>;
