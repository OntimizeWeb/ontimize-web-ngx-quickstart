import * as i0 from '@angular/core';
import { Pipe, Component, Directive, ViewEncapsulation, Optional, Inject, ViewChild, ContentChild, Input, NgModule } from '@angular/core';
import * as i5 from '@angular/flex-layout';
import { FlexLayoutModule } from '@angular/flex-layout';
import * as i1$1 from '@angular/common';
import { CommonModule } from '@angular/common';
import * as i2 from 'ontimize-web-ngx';
import { OTranslateService, Util, Codes, O_TABLE_GLOBAL_CONFIG, OTableModule, OGridModule, OButtonToggleModule, OntimizeWebModule } from 'ontimize-web-ngx';
import * as i1 from 'ngx-skeleton-loader';
import { NgxSkeletonLoaderModule } from 'ngx-skeleton-loader';

const MAP = {
    // English
    en: {},
    // Spanish
    es: {}
};

class OExtraComponentsTranslatePipe {
    constructor(injector) {
        this.injector = injector;
        this.translateService = this.injector.get(OTranslateService);
    }
    transform(text) {
        let textTranslated = undefined;
        let bundle = MAP[this.translateService.getCurrentLang()];
        if (bundle && bundle[text]) {
            textTranslated = bundle[text];
        }
        else {
            textTranslated = this.translateService.get(text);
        }
        return textTranslated;
    }
}
OExtraComponentsTranslatePipe.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: OExtraComponentsTranslatePipe, deps: [{ token: i0.Injector }], target: i0.ɵɵFactoryTarget.Pipe });
OExtraComponentsTranslatePipe.ɵpipe = i0.ɵɵngDeclarePipe({ minVersion: "14.0.0", version: "15.2.10", ngImport: i0, type: OExtraComponentsTranslatePipe, name: "oExtraComponentsTranslate", pure: false });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: OExtraComponentsTranslatePipe, decorators: [{
            type: Pipe,
            args: [{
                    name: 'oExtraComponentsTranslate',
                    pure: false
                }]
        }], ctorParameters: function () { return [{ type: i0.Injector }]; } });

class OSkeletonComponent {
}
OSkeletonComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: OSkeletonComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
OSkeletonComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "15.2.10", type: OSkeletonComponent, selector: "o-skeleton", host: { properties: { "class.o-skeleton": "true" } }, ngImport: i0, template: "<div class=\"fb-item\">\r\n  <div class=\"first-section-wrapper\">\r\n    <div class=\"gravatar\">\r\n      <ngx-skeleton-loader appearance=\"circle\" [theme]=\"{ width: '80px', height: '80px' }\">\r\n      </ngx-skeleton-loader>\r\n    </div>\r\n    <div class=\"gravatar-title\">\r\n      <div>\r\n        <ngx-skeleton-loader [theme]=\"{\r\n            width: '200px',\r\n            'border-radius': '0',\r\n            height: '15px',\r\n            'margin-bottom': '10px'\r\n          }\"></ngx-skeleton-loader>\r\n      </div>\r\n      <div>\r\n        <ngx-skeleton-loader [theme]=\"{ width: '170px', 'border-radius': '0', height: '15px' }\">\r\n        </ngx-skeleton-loader>\r\n      </div>\r\n    </div>\r\n  </div>\r\n  <div class=\"second-section-wrapper\">\r\n    <div class=\"wrapper\">\r\n      <ngx-skeleton-loader [theme]=\"{\r\n          width: '80%',\r\n          'border-radius': '0',\r\n          height: '15px',\r\n          'margin-bottom': '10px'\r\n        }\"></ngx-skeleton-loader>\r\n    </div>\r\n    <div class=\"wrapper\">\r\n      <ngx-skeleton-loader [theme]=\"{\r\n          width: '90%',\r\n          'border-radius': '0',\r\n          height: '15px',\r\n          'margin-bottom': '10px'\r\n        }\"></ngx-skeleton-loader>\r\n    </div>\r\n    <div class=\"wrapper\">\r\n      <ngx-skeleton-loader [theme]=\"{\r\n          width: '60%',\r\n          'border-radius': '0',\r\n          height: '15px',\r\n          'margin-bottom': '10px'\r\n        }\"></ngx-skeleton-loader>\r\n    </div>\r\n    <div class=\"wrapper\">\r\n      <ngx-skeleton-loader [theme]=\"{\r\n                width: '80%',\r\n                'border-radius': '0',\r\n                height: '15px',\r\n                'margin-bottom': '10px'\r\n              }\"></ngx-skeleton-loader>\r\n    </div>\r\n    <div class=\"wrapper\">\r\n      <ngx-skeleton-loader [theme]=\"{\r\n                width: '90%',\r\n                'border-radius': '0',\r\n                height: '15px',\r\n                'margin-bottom': '10px'\r\n              }\"></ngx-skeleton-loader>\r\n    </div>\r\n    <div class=\"wrapper\">\r\n      <ngx-skeleton-loader [theme]=\"{\r\n                width: '60%',\r\n                'border-radius': '0',\r\n                height: '15px',\r\n                'margin-bottom': '10px'\r\n              }\"></ngx-skeleton-loader>\r\n    </div>\r\n    <div class=\"wrapper\">\r\n      <ngx-skeleton-loader [theme]=\"{\r\n                width: '80%',\r\n                'border-radius': '0',\r\n                height: '15px',\r\n                'margin-bottom': '10px'\r\n              }\"></ngx-skeleton-loader>\r\n    </div>\r\n    <div class=\"wrapper\">\r\n      <ngx-skeleton-loader [theme]=\"{\r\n                width: '90%',\r\n                'border-radius': '0',\r\n                height: '15px',\r\n                'margin-bottom': '10px'\r\n              }\"></ngx-skeleton-loader>\r\n    </div>\r\n    <div class=\"wrapper\">\r\n      <ngx-skeleton-loader [theme]=\"{\r\n                width: '60%',\r\n                'border-radius': '0',\r\n                height: '15px',\r\n                'margin-bottom': '10px'\r\n              }\"></ngx-skeleton-loader>\r\n    </div>\r\n    <div class=\"wrapper\">\r\n      <ngx-skeleton-loader [theme]=\"{\r\n                width: '80%',\r\n                'border-radius': '0',\r\n                height: '15px',\r\n                'margin-bottom': '10px'\r\n              }\"></ngx-skeleton-loader>\r\n    </div>\r\n    <div class=\"wrapper\">\r\n      <ngx-skeleton-loader [theme]=\"{\r\n                width: '90%',\r\n                'border-radius': '0',\r\n                height: '15px',\r\n                'margin-bottom': '10px'\r\n              }\"></ngx-skeleton-loader>\r\n    </div>\r\n    <div class=\"wrapper\">\r\n      <ngx-skeleton-loader [theme]=\"{\r\n                width: '60%',\r\n                'border-radius': '0',\r\n                height: '15px',\r\n                'margin-bottom': '10px'\r\n              }\"></ngx-skeleton-loader>\r\n    </div>\r\n  </div>\r\n  <div class=\"wrapper\">\r\n    <ngx-skeleton-loader [theme]=\"{\r\n              width: '80%',\r\n              'border-radius': '0',\r\n              height: '15px',\r\n              'margin-bottom': '10px'\r\n            }\"></ngx-skeleton-loader>\r\n  </div>\r\n  <div class=\"wrapper\">\r\n    <ngx-skeleton-loader [theme]=\"{\r\n              width: '90%',\r\n              'border-radius': '0',\r\n              height: '15px',\r\n              'margin-bottom': '10px'\r\n            }\"></ngx-skeleton-loader>\r\n  </div>\r\n  <div class=\"wrapper\">\r\n    <ngx-skeleton-loader [theme]=\"{\r\n              width: '60%',\r\n              'border-radius': '0',\r\n              height: '15px',\r\n              'margin-bottom': '10px'\r\n            }\"></ngx-skeleton-loader>\r\n  </div>\r\n  <div class=\"wrapper\">\r\n    <ngx-skeleton-loader [theme]=\"{\r\n              width: '80%',\r\n              'border-radius': '0',\r\n              height: '15px',\r\n              'margin-bottom': '10px'\r\n            }\"></ngx-skeleton-loader>\r\n  </div>\r\n  <div class=\"wrapper\">\r\n    <ngx-skeleton-loader [theme]=\"{\r\n              width: '90%',\r\n              'border-radius': '0',\r\n              height: '15px',\r\n              'margin-bottom': '10px'\r\n            }\"></ngx-skeleton-loader>\r\n  </div>\r\n  <div class=\"wrapper\">\r\n    <ngx-skeleton-loader [theme]=\"{\r\n              width: '60%',\r\n              'border-radius': '0',\r\n              height: '15px',\r\n              'margin-bottom': '10px'\r\n            }\"></ngx-skeleton-loader>\r\n  </div>\r\n</div>\r\n", styles: [".item,.fb-item{width:auto;height:auto;margin:10px auto;border:1px solid #eaeaea;padding:10px}.gravatar{width:100px;height:90px}.gravatar-title{width:500px;padding:10px;height:80px}.first-section-wrapper,.second-section-wrapper{width:100%;height:auto;flex:1}.first-section-wrapper{display:inline-flex}\n"], dependencies: [{ kind: "component", type: i1.NgxSkeletonLoaderComponent, selector: "ngx-skeleton-loader", inputs: ["count", "loadingText", "appearance", "animation", "ariaLabel", "theme"] }] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: OSkeletonComponent, decorators: [{
            type: Component,
            args: [{ selector: 'o-skeleton', host: {
                        '[class.o-skeleton]': 'true'
                    }, template: "<div class=\"fb-item\">\r\n  <div class=\"first-section-wrapper\">\r\n    <div class=\"gravatar\">\r\n      <ngx-skeleton-loader appearance=\"circle\" [theme]=\"{ width: '80px', height: '80px' }\">\r\n      </ngx-skeleton-loader>\r\n    </div>\r\n    <div class=\"gravatar-title\">\r\n      <div>\r\n        <ngx-skeleton-loader [theme]=\"{\r\n            width: '200px',\r\n            'border-radius': '0',\r\n            height: '15px',\r\n            'margin-bottom': '10px'\r\n          }\"></ngx-skeleton-loader>\r\n      </div>\r\n      <div>\r\n        <ngx-skeleton-loader [theme]=\"{ width: '170px', 'border-radius': '0', height: '15px' }\">\r\n        </ngx-skeleton-loader>\r\n      </div>\r\n    </div>\r\n  </div>\r\n  <div class=\"second-section-wrapper\">\r\n    <div class=\"wrapper\">\r\n      <ngx-skeleton-loader [theme]=\"{\r\n          width: '80%',\r\n          'border-radius': '0',\r\n          height: '15px',\r\n          'margin-bottom': '10px'\r\n        }\"></ngx-skeleton-loader>\r\n    </div>\r\n    <div class=\"wrapper\">\r\n      <ngx-skeleton-loader [theme]=\"{\r\n          width: '90%',\r\n          'border-radius': '0',\r\n          height: '15px',\r\n          'margin-bottom': '10px'\r\n        }\"></ngx-skeleton-loader>\r\n    </div>\r\n    <div class=\"wrapper\">\r\n      <ngx-skeleton-loader [theme]=\"{\r\n          width: '60%',\r\n          'border-radius': '0',\r\n          height: '15px',\r\n          'margin-bottom': '10px'\r\n        }\"></ngx-skeleton-loader>\r\n    </div>\r\n    <div class=\"wrapper\">\r\n      <ngx-skeleton-loader [theme]=\"{\r\n                width: '80%',\r\n                'border-radius': '0',\r\n                height: '15px',\r\n                'margin-bottom': '10px'\r\n              }\"></ngx-skeleton-loader>\r\n    </div>\r\n    <div class=\"wrapper\">\r\n      <ngx-skeleton-loader [theme]=\"{\r\n                width: '90%',\r\n                'border-radius': '0',\r\n                height: '15px',\r\n                'margin-bottom': '10px'\r\n              }\"></ngx-skeleton-loader>\r\n    </div>\r\n    <div class=\"wrapper\">\r\n      <ngx-skeleton-loader [theme]=\"{\r\n                width: '60%',\r\n                'border-radius': '0',\r\n                height: '15px',\r\n                'margin-bottom': '10px'\r\n              }\"></ngx-skeleton-loader>\r\n    </div>\r\n    <div class=\"wrapper\">\r\n      <ngx-skeleton-loader [theme]=\"{\r\n                width: '80%',\r\n                'border-radius': '0',\r\n                height: '15px',\r\n                'margin-bottom': '10px'\r\n              }\"></ngx-skeleton-loader>\r\n    </div>\r\n    <div class=\"wrapper\">\r\n      <ngx-skeleton-loader [theme]=\"{\r\n                width: '90%',\r\n                'border-radius': '0',\r\n                height: '15px',\r\n                'margin-bottom': '10px'\r\n              }\"></ngx-skeleton-loader>\r\n    </div>\r\n    <div class=\"wrapper\">\r\n      <ngx-skeleton-loader [theme]=\"{\r\n                width: '60%',\r\n                'border-radius': '0',\r\n                height: '15px',\r\n                'margin-bottom': '10px'\r\n              }\"></ngx-skeleton-loader>\r\n    </div>\r\n    <div class=\"wrapper\">\r\n      <ngx-skeleton-loader [theme]=\"{\r\n                width: '80%',\r\n                'border-radius': '0',\r\n                height: '15px',\r\n                'margin-bottom': '10px'\r\n              }\"></ngx-skeleton-loader>\r\n    </div>\r\n    <div class=\"wrapper\">\r\n      <ngx-skeleton-loader [theme]=\"{\r\n                width: '90%',\r\n                'border-radius': '0',\r\n                height: '15px',\r\n                'margin-bottom': '10px'\r\n              }\"></ngx-skeleton-loader>\r\n    </div>\r\n    <div class=\"wrapper\">\r\n      <ngx-skeleton-loader [theme]=\"{\r\n                width: '60%',\r\n                'border-radius': '0',\r\n                height: '15px',\r\n                'margin-bottom': '10px'\r\n              }\"></ngx-skeleton-loader>\r\n    </div>\r\n  </div>\r\n  <div class=\"wrapper\">\r\n    <ngx-skeleton-loader [theme]=\"{\r\n              width: '80%',\r\n              'border-radius': '0',\r\n              height: '15px',\r\n              'margin-bottom': '10px'\r\n            }\"></ngx-skeleton-loader>\r\n  </div>\r\n  <div class=\"wrapper\">\r\n    <ngx-skeleton-loader [theme]=\"{\r\n              width: '90%',\r\n              'border-radius': '0',\r\n              height: '15px',\r\n              'margin-bottom': '10px'\r\n            }\"></ngx-skeleton-loader>\r\n  </div>\r\n  <div class=\"wrapper\">\r\n    <ngx-skeleton-loader [theme]=\"{\r\n              width: '60%',\r\n              'border-radius': '0',\r\n              height: '15px',\r\n              'margin-bottom': '10px'\r\n            }\"></ngx-skeleton-loader>\r\n  </div>\r\n  <div class=\"wrapper\">\r\n    <ngx-skeleton-loader [theme]=\"{\r\n              width: '80%',\r\n              'border-radius': '0',\r\n              height: '15px',\r\n              'margin-bottom': '10px'\r\n            }\"></ngx-skeleton-loader>\r\n  </div>\r\n  <div class=\"wrapper\">\r\n    <ngx-skeleton-loader [theme]=\"{\r\n              width: '90%',\r\n              'border-radius': '0',\r\n              height: '15px',\r\n              'margin-bottom': '10px'\r\n            }\"></ngx-skeleton-loader>\r\n  </div>\r\n  <div class=\"wrapper\">\r\n    <ngx-skeleton-loader [theme]=\"{\r\n              width: '60%',\r\n              'border-radius': '0',\r\n              height: '15px',\r\n              'margin-bottom': '10px'\r\n            }\"></ngx-skeleton-loader>\r\n  </div>\r\n</div>\r\n", styles: [".item,.fb-item{width:auto;height:auto;margin:10px auto;border:1px solid #eaeaea;padding:10px}.gravatar{width:100px;height:90px}.gravatar-title{width:500px;padding:10px;height:80px}.first-section-wrapper,.second-section-wrapper{width:100%;height:auto;flex:1}.first-section-wrapper{display:inline-flex}\n"] }]
        }] });

class ODataViewGridItemDirective {
    constructor(template) {
        this.template = template;
    }
}
ODataViewGridItemDirective.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: ODataViewGridItemDirective, deps: [{ token: i0.TemplateRef }], target: i0.ɵɵFactoryTarget.Directive });
ODataViewGridItemDirective.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "15.2.10", type: ODataViewGridItemDirective, selector: "[oDataViewGridItem]", ngImport: i0 });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: ODataViewGridItemDirective, decorators: [{
            type: Directive,
            args: [{ selector: '[oDataViewGridItem]' }]
        }], ctorParameters: function () { return [{ type: i0.TemplateRef }]; } });

class ODataViewTableColumnsDirective {
    constructor(templateRef) {
        this.templateRef = templateRef;
    }
}
ODataViewTableColumnsDirective.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: ODataViewTableColumnsDirective, deps: [{ token: i0.TemplateRef }], target: i0.ɵɵFactoryTarget.Directive });
ODataViewTableColumnsDirective.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "15.2.10", type: ODataViewTableColumnsDirective, selector: "ng-template[oDataViewTableColumns]", ngImport: i0 });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: ODataViewTableColumnsDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: 'ng-template[oDataViewTableColumns]'
                }]
        }], ctorParameters: function () { return [{ type: i0.TemplateRef }]; } });

class ODataViewComponent {
    constructor(vcr, tableGlobalConfig) {
        this.vcr = vcr;
        this.tableGlobalConfig = tableGlobalConfig;
        this.showToggleOnToolbar = false;
        this.showToggleFloatable = false;
        this.showToggleButton = true;
        this.columnsView = null;
    }
    ngOnInit() {
        if (!this.defaultView)
            this.defaultView = 'table';
        this.showToggleOnToolbar = Util.parseBoolean(this.toggleOnToolbar, false);
        this.showToggleFloatable = Util.parseBoolean(this.toggleFloatable, false);
        this.showToggleButton = Util.parseBoolean(this.toggleButton, true);
    }
    ngAfterViewInit() {
        // Initialize and synchronize table columns once the view and projected content are ready
        if (this.tableTpl && this.table) {
            this.syncTableColumnsWithTable();
        }
    }
    ngOnDestroy() {
        // Clean up the created view to avoid memory leaks
        if (this.columnsView) {
            this.columnsView.destroy();
            this.columnsView = null;
        }
    }
    syncTableColumnsWithTable() {
        if (!this.tableTpl || !this.table?.injector) {
            return;
        }
        try {
            // Create the embedded view with the correct injector
            this.columnsView = this.vcr.createEmbeddedView(this.tableTpl.templateRef, {}, { injector: this.table.injector });
            // Detect changes to ensure nodes are fully initialized
            this.columnsView.detectChanges();
            setTimeout(() => {
                this.table.parseVisibleColumns(true);
                if (Util.isDefined(this.table.oTableColumnsGroupingComponent)) {
                    this.table.setGroupColumns(this.table.oTableColumnsGroupingComponent.columnsArray);
                }
            }, 0);
        }
        catch (error) {
            console.error('Error registering table columns:', error);
        }
    }
    changeView(value) {
        const previousView = this.defaultView;
        if (this.toggleGroup) {
            this.defaultView = this.toggleGroup.getValue();
        }
        else {
            this.defaultView = value;
        }
        // If switching to table and columns aren't registered, register them
        if (this.defaultView === 'table' && previousView !== 'table') {
            setTimeout(() => this.syncTableColumnsWithTable(), 0);
        }
    }
    ngOnChanges() {
        this.resolveCommonInputs();
        this.resolveTableInputs();
        this.resolveGridInputs();
    }
    resolveCommonInputs() {
        this.r_columns = this.setDefaultValue(this.columns, '');
        this.r_keys = this.setDefaultValue(this.keys, '');
        this.r_attr = this.setDefaultValue(this.attr, '');
        this.r_entity = this.setDefaultValue(this.entity, '');
        this.r_service = this.setDefaultValue(this.service, '');
        this.r_serviceType = this.setDefaultValue(this.serviceType, '');
        this.r_paginatedQueryMethod = this.setDefaultValue(this.paginatedQueryMethod, Codes.PAGINATED_QUERY_METHOD);
        this.r_parentKeys = this.setDefaultValue(this.parentKeys, '');
        this.r_queryMethod = this.setDefaultValue(this.queryMethod, Codes.QUERY_METHOD);
        this.r_configureServiceArgs = this.configureServiceArgs;
        this.r_queryFallbackFunction = this.queryFallbackFunction;
        this.r_staticData = this.staticData;
        this.r_pageable = this.setDefaultValue(this.pageable, 'no');
        this.r_queryOnInit = this.setDefaultValue(this.queryOnInit, 'yes');
        this.r_queryOnBind = this.setDefaultValue(this.queryOnBind, 'yes');
        this.r_queryWithNullParentKeys = this.setDefaultValue(this.queryWithNullParentKeys, 'no');
        this.r_storeState = this.setDefaultValue(this.storeState, 'yes');
        this.r_queryRows = this.setDefaultNumber(this.queryRows, Codes.DEFAULT_QUERY_ROWS);
        this.r_deleteMethod = this.setDefaultValue(this.deleteMethod, Codes.DELETE_METHOD);
        this.r_insertMethod = this.setDefaultValue(this.insertMethod, Codes.INSERT_METHOD);
        this.r_updateMethod = this.setDefaultValue(this.updateMethod, Codes.UPDATE_METHOD);
        this.r_showButtonsText = this.setDefaultValue(this.showButtonsText, 'yes');
        this.r_quickFilterPlaceholder = this.setDefaultValue(this.quickFilterPlaceholder, '');
        this.r_insertButton = this.setDefaultValue(this.insertButton, 'yes');
        this.r_refreshButton = this.setDefaultValue(this.refreshButton, 'yes');
        this.r_fixedHeader = this.setDefaultValue(this.fixedHeader, 'yes');
        this.r_controls = this.setDefaultValue(this.controls, 'yes');
        this.r_detailFormRoute = this.setDefaultValue(this.detailFormRoute, '');
        this.r_filterCaseSensitive = this.setDefaultValue(this.filterCaseSensitive, 'no');
        this.r_paginationControls = this.setDefaultValue(this.paginationControls, 'yes');
        this.r_quickFilter = this.setDefaultValue(this.quickFilter, 'yes');
        this.r_recursiveDetail = this.setDefaultValue(this.recursiveDetail, 'no');
        this.r_recursiveEdit = this.setDefaultValue(this.recursiveEdit, 'no');
        this.r_recursiveInsert = this.setDefaultValue(this.recursiveInsert, 'no');
        this.r_insertFormRoute = this.setDefaultValue(this.insertFormRoute, Codes.DEFAULT_INSERT_ROUTE);
        this.r_title = this.setDefaultValue(this.title, '');
        this.r_quickFilterAppearance = this.setDefaultValue(this.quickFilterAppearance, 'outline');
    }
    resolveTableInputs() {
        const cfg = this.tableConfig ?? {};
        const g = this.tableGlobalConfig;
        this.r_table_detailButtonInRow = this.setDefaultValue(cfg.detailButtonInRow, 'no');
        this.r_table_detailButtonInRowIcon = this.setDefaultValue(cfg.detailButtonInRowIcon, Codes.DETAIL_ICON);
        this.r_table_editButtonInRow = this.setDefaultValue(cfg.editButtonInRow, 'no');
        this.r_table_editButtonInRowIcon = this.setDefaultValue(cfg.editButtonInRowIcon, Codes.EDIT_ICON);
        this.r_table_editFormRoute = this.setDefaultValue(cfg.editFormRoute, '');
        this.r_table_enabled = this.setDefaultValue(cfg.enabled, 'yes');
        this.r_table_rowHeight = this.resolveStringWithGlobal(cfg.rowHeight, g?.rowHeight, Codes.DEFAULT_ROW_HEIGHT);
        this.r_table_visible = this.setDefaultValue(cfg.visible, 'yes');
        this.r_table_autoAdjust = this.resolveYesNoWithGlobal(cfg.autoAdjust, g?.autoAdjust, 'yes');
        this.r_table_autoAlignTitles = this.resolveYesNoWithGlobal(cfg.autoAlignTitles, g?.autoAlignTitles, 'yes');
        this.r_table_collapseGroupedColumns = this.setDefaultValue(cfg.collapseGroupedColumns, 'no');
        this.r_table_columnsVisibilityButton = this.setDefaultValue(cfg.columnsVisibilityButton, 'yes');
        this.r_table_defaultVisibleColumns = this.setDefaultValue(cfg.defaultVisibleColumns, '');
        this.r_table_deleteButton = this.setDefaultValue(cfg.deleteButton, 'yes');
        this.r_table_editionMode = this.resolveStringWithGlobal(cfg.editionMode, g?.editionMode, Codes.EDITION_MODE_NONE);
        this.r_table_exportButton = this.setDefaultValue(cfg.exportButton, 'yes');
        this.r_table_exportServiceType = this.setDefaultValue(cfg.exportServiceType, 'OntimizeExportService');
        this.r_table_filterColumnActiveByDefault = this.resolveYesNoWithGlobal(cfg.filterColumnActiveByDefault, g?.filterColumnActiveByDefault, 'yes');
        this.r_table_groupable = this.setDefaultValue(cfg.groupable, 'yes');
        this.r_table_groupedColumns = this.setDefaultValue(cfg.groupedColumns, '');
        this.r_table_horizontalScroll = this.setDefaultValue(cfg.horizontalScroll, 'no');
        this.r_table_multipleSort = this.setDefaultValue(cfg.multipleSort, 'yes');
        this.r_table_nonHidableColumns = this.setDefaultValue(cfg.nonHidableColumns, '');
        this.r_table_pageSizeOptions = this.setDefaultArray(cfg.pageSizeOptions, Codes.PAGE_SIZE_OPTIONS);
        this.r_table_resizable = this.setDefaultValue(cfg.resizable, 'yes');
        this.r_table_selectAllCheckbox = this.setDefaultValue(cfg.selectAllCheckbox, 'no');
        this.r_table_selectAllCheckboxVisible = this.setDefaultValue(cfg.selectAllCheckboxVisible, 'no');
        this.r_table_selectionMode = this.setDefaultValue(cfg.selectionMode, Codes.SELECTION_MODE_MULTIPLE);
        this.r_table_showConfigurationOption = this.setDefaultValue(cfg.showConfigurationOption, 'yes');
        this.r_table_showFilterOption = this.setDefaultValue(cfg.showFilterOption, 'yes');
        this.r_table_showPaginatorFirstLastButtons = this.setDefaultValue(cfg.showPaginatorFirstLastButtons, 'yes');
        this.r_table_showChartsOnDemandOption = this.setDefaultValue(cfg.showChartsOnDemandOption, 'yes');
        this.r_table_showReportOnDemandOption = this.setDefaultValue(cfg.showReportOnDemandOption, 'yes');
        this.r_table_showResetWidthOption = this.setDefaultValue(cfg.showResetWidthOption, 'yes');
        this.r_table_sortColumns = this.setDefaultValue(cfg.sortColumns, '');
        this.r_table_virtualScroll = this.setDefaultValue(cfg.virtualScroll, 'yes');
        this.r_table_visibleColumns = this.setDefaultValue(cfg.visibleColumns, '');
        this.r_table_visibleExportDialogButtons = this.setDefaultValue(cfg.visibleExportDialogButtons, '');
        this.r_table_selectionOnRowClick = this.resolveYesNoWithGlobal(cfg.selectionOnRowClick, g?.selectionOnRowClick, 'yes');
        this.r_table_detailMode = this.resolveStringWithGlobal(cfg.detailMode, g?.detailMode, Codes.DETAIL_MODE_CLICK);
        this.r_table_disableSelectionFunction = cfg.disableSelectionFunction;
        this.r_table_quickFilterFunction = cfg.quickFilterFunction;
        this.r_table_rowClass = cfg.rowClass;
        this.r_table_showExpandableIconFunction = cfg.showExpandableIconFunction;
    }
    resolveGridInputs() {
        const cfg = this.gridConfig ?? {};
        this.r_grid_enabled = this.setDefaultValue(cfg.enabled, 'yes');
        this.r_grid_visible = this.setDefaultValue(cfg.visible, 'yes');
        this.r_grid_cols = cfg.cols;
        this.r_grid_gridItemHeight = this.setDefaultValueAny(cfg?.gridItemHeight, '1:1');
        this.r_grid_gutterSize = this.setDefaultValue(cfg.gutterSize, '1px');
        this.r_grid_insertButtonFloatable = this.setDefaultValue(cfg.insertButtonFloatable, 'yes');
        this.r_grid_insertButtonPosition = this.setDefaultValue(cfg.insertButtonPosition, 'bottom');
        this.r_grid_orderable = this.setDefaultValue(cfg.orderable, 'no');
        this.r_grid_showFooter = this.setDefaultValue(cfg.showFooter, 'yes');
        this.r_grid_showPageSize = this.setDefaultValue(cfg.showPageSize, 'no');
        this.r_grid_sortColumn = this.setDefaultValue(cfg.sortColumn, '');
        this.r_grid_sortableColumns = this.setDefaultValue(cfg.sortableColumns, '');
        this.r_grid_detailMode = this.setDefaultValue(cfg.detailMode, Codes.DETAIL_MODE_CLICK);
        this.r_grid_pageSizeOptions = this.setDefaultArray(cfg.pageSizeOptions, [8, 16, 24, 32, 64]);
        this.r_grid_quickFilterColumns = this.setDefaultValue(cfg.quickFilterColumns, this.r_columns);
    }
    setDefaultValue(v, def) {
        if (v === undefined || v === null || v === '')
            return def;
        return v;
    }
    setDefaultValueAny(v, def) {
        if (v === undefined || v === null)
            return def;
        if (typeof v === 'string' && v === '')
            return def;
        return v;
    }
    setDefaultNumber(v, def) {
        if (v === undefined || v === null)
            return def;
        return v;
    }
    setDefaultArray(v, def) {
        if (v === undefined || v === null)
            return def;
        return v;
    }
    resolveYesNoWithGlobal(inputVal, globalVal, defaultVal) {
        const inputResolved = this.setDefaultValue(inputVal, defaultVal);
        if (inputResolved !== undefined)
            return inputResolved;
        if (globalVal !== undefined && globalVal !== null) {
            return globalVal ? 'yes' : 'no';
        }
        return defaultVal;
    }
    resolveStringWithGlobal(inputVal, globalVal, defaultVal) {
        const inputResolved = this.setDefaultValue(inputVal, defaultVal);
        if (inputResolved !== undefined)
            return inputResolved;
        const globalResolved = this.setDefaultValue(globalVal, defaultVal);
        if (globalResolved !== undefined)
            return globalResolved;
        return defaultVal;
    }
}
ODataViewComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: ODataViewComponent, deps: [{ token: i0.ViewContainerRef }, { token: O_TABLE_GLOBAL_CONFIG, optional: true }], target: i0.ɵɵFactoryTarget.Component });
ODataViewComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "15.2.10", type: ODataViewComponent, selector: "o-data-view", inputs: { defaultView: ["default-view", "defaultView"], toggleOnToolbar: ["toggle-on-toolbar", "toggleOnToolbar"], toggleFloatable: ["toggle-floatable", "toggleFloatable"], toggleButton: ["toggle-button", "toggleButton"], attr: "attr", columns: "columns", configureServiceArgs: ["configure-service-args", "configureServiceArgs"], deleteMethod: ["delete-method", "deleteMethod"], entity: "entity", insertMethod: ["insert-method", "insertMethod"], keys: "keys", pageable: "pageable", paginatedQueryMethod: ["paginated-query-method", "paginatedQueryMethod"], parentKeys: ["parent-keys", "parentKeys"], queryFallbackFunction: ["query-fallback-function", "queryFallbackFunction"], queryMethod: ["query-method", "queryMethod"], queryOnBind: ["query-on-bind", "queryOnBind"], queryOnInit: ["query-on-init", "queryOnInit"], queryRows: ["query-rows", "queryRows"], queryWithNullParentKeys: ["query-with-null-parent-keys", "queryWithNullParentKeys"], service: "service", serviceType: ["service-type", "serviceType"], staticData: ["static-data", "staticData"], storeState: ["store-state", "storeState"], updateMethod: ["update-method", "updateMethod"], showButtonsText: ["show-buttons-text", "showButtonsText"], quickFilterPlaceholder: ["quick-filter-placeholder", "quickFilterPlaceholder"], insertButton: ["insert-button", "insertButton"], refreshButton: ["refresh-button", "refreshButton"], fixedHeader: ["fixed-header", "fixedHeader"], controls: "controls", title: "title", quickFilter: ["quick-filter", "quickFilter"], quickFilterAppearance: ["quick-filter-appearance", "quickFilterAppearance"], recursiveDetail: ["recursive-detail", "recursiveDetail"], recursiveEdit: ["recursive-edit", "recursiveEdit"], recursiveInsert: ["recursive-insert", "recursiveInsert"], detailFormRoute: ["detail-form-route", "detailFormRoute"], paginationControls: ["pagination-controls", "paginationControls"], insertFormRoute: ["insert-form-route", "insertFormRoute"], filterCaseSensitive: ["filter-case-sensitive", "filterCaseSensitive"], tableConfig: ["table-config", "tableConfig"], gridConfig: ["grid-config", "gridConfig"] }, queries: [{ propertyName: "gridItemTpl", first: true, predicate: ODataViewGridItemDirective, descendants: true }, { propertyName: "tableTpl", first: true, predicate: ODataViewTableColumnsDirective, descendants: true }], viewQueries: [{ propertyName: "table", first: true, predicate: ["table"], descendants: true }, { propertyName: "grid", first: true, predicate: ["grid"], descendants: true }, { propertyName: "toggleGroup", first: true, predicate: ["toggleGroup"], descendants: true }], usesOnChanges: true, ngImport: i0, template: "<div class=\"o-data-view-container\">\r\n\r\n  <o-button-toggle-group #toggleGroup *ngIf=\"!showToggleOnToolbar && !showToggleFloatable && showToggleButton\" class=\"button-toggle-group\"\r\n    attr=\"toggleGroup\" multiple=\"no\" [value]=\"defaultView\" (onChange)=\"changeView($event)\">\r\n    <o-button-toggle attr=\"toggle1\" value=\"table\" icon=\"storage\"></o-button-toggle>\r\n    <o-button-toggle attr=\"toggle2\" value=\"grid\" icon=\"view_module\"></o-button-toggle>\r\n  </o-button-toggle-group>\r\n\r\n  <div class=\"o-data-view-component\">\r\n\r\n    <o-table #table *ngIf=\"defaultView === 'table'\" [attr]=\"r_attr\" [columns]=\"r_columns\" [configure-service-args]=\"r_configureServiceArgs\"\r\n      [entity]=\"r_entity\" [keys]=\"r_keys\" [pageable]=\"r_pageable\" [paginated-query-method]=\"r_paginatedQueryMethod\" [parent-keys]=\"r_parentKeys\"\r\n      [query-fallback-function]=\"r_queryFallbackFunction\" [query-method]=\"r_queryMethod\" [query-on-bind]=\"r_queryOnBind\"\r\n      [query-on-init]=\"r_queryOnInit\" [query-rows]=\"r_queryRows\" [query-with-null-parent-keys]=\"r_queryWithNullParentKeys\" [service]=\"r_service\"\r\n      [service-type]=\"r_serviceType\" [static-data]=\"r_staticData\" [store-state]=\"r_storeState\" [delete-method]=\"r_deleteMethod\"\r\n      [insert-method]=\"r_insertMethod\" [update-method]=\"r_updateMethod\" [controls]=\"r_controls\"\r\n      [detail-button-in-row]=\"r_table_detailButtonInRow\" [detail-button-in-row-icon]=\"r_table_detailButtonInRowIcon\"\r\n      [detail-form-route]=\"r_detailFormRoute\" [detail-mode]=\"r_table_detailMode\" [edit-button-in-row]=\"r_table_editButtonInRow\"\r\n      [edit-button-in-row-icon]=\"r_table_editButtonInRowIcon\" [edit-form-route]=\"r_table_editFormRoute\" [enabled]=\"r_table_enabled\"\r\n      [filter-case-sensitive]=\"r_filterCaseSensitive\" [insert-button]=\"r_insertButton\" [insert-form-route]=\"r_insertFormRoute\"\r\n      [page-size-options]=\"r_table_pageSizeOptions\" [pagination-controls]=\"r_paginationControls\" [quick-filter]=\"r_quickFilter\"\r\n      [quick-filter-placeholder]=\"r_quickFilterPlaceholder\" [recursive-detail]=\"r_recursiveDetail\" [recursive-edit]=\"r_recursiveEdit\"\r\n      [recursive-insert]=\"r_recursiveInsert\" [row-height]=\"r_table_rowHeight\" [title]=\"r_title\" [visible]=\"r_table_visible\"\r\n      [auto-adjust]=\"r_table_autoAdjust\" [auto-align-titles]=\"r_table_autoAlignTitles\" [collapse-grouped-columns]=\"r_table_collapseGroupedColumns\"\r\n      [columns-visibility-button]=\"r_table_columnsVisibilityButton\" [default-visible-columns]=\"r_table_defaultVisibleColumns\"\r\n      [delete-button]=\"r_table_deleteButton\" [disable-selection-function]=\"r_table_disableSelectionFunction\" [edition-mode]=\"r_table_editionMode\"\r\n      [export-button]=\"r_table_exportButton\" [export-service-type]=\"r_table_exportServiceType\"\r\n      [filter-column-active-by-default]=\"r_table_filterColumnActiveByDefault\" [fixed-header]=\"r_fixedHeader\" [groupable]=\"r_table_groupable\"\r\n      [grouped-columns]=\"r_table_groupedColumns\" [horizontal-scroll]=\"r_table_horizontalScroll\" [keep-selected-items]=\"r_table_keepSelectedItems\"\r\n      [multiple-sort]=\"r_table_multipleSort\" [non-hidable-columns]=\"r_table_nonHidableColumns\" [quick-filter-function]=\"r_table_quickFilterFunction\"\r\n      [refresh-button]=\"r_refreshButton\" [resizable]=\"r_table_resizable\" [row-class]=\"r_table_rowClass\"\r\n      [select-all-checkbox]=\"r_table_selectAllCheckbox\" [select-all-checkbox-visible]=\"r_table_selectAllCheckboxVisible\"\r\n      [selection-mode]=\"r_table_selectionMode\" [show-buttons-text]=\"r_showButtonsText\" [show-configuration-option]=\"r_table_showConfigurationOption\"\r\n      [show-expandable-icon-function]=\"r_table_showExpandableIconFunction\" [show-filter-option]=\"r_table_showFilterOption\"\r\n      [show-paginator-first-last-buttons]=\"r_table_showPaginatorFirstLastButtons\" [show-report-on-demand-option]=\"r_table_showReportOnDemandOption\"\r\n      [show-reset-width-option]=\"r_table_showResetWidthOption\" [sort-columns]=\"r_table_sortColumns\"\r\n      [virtual-scroll]=\"r_table_virtualScroll\" [visible-columns]=\"r_table_visibleColumns\"\r\n      [visible-export-dialog-buttons]=\"r_table_visibleExportDialogButtons\" [show-charts-on-demand-option]=\"r_table_showChartsOnDemandOption\" show-title=\"yes\">\r\n\r\n      <o-button-toggle-group #toggleGroup *ngIf=\"showToggleOnToolbar\" class=\"toggle-toolbar\" attr=\"toggleGroup\" o-table-toolbar position=\"end\"\r\n        multiple=\"no\" [value]=\"defaultView\" (onChange)=\"changeView($event)\">\r\n        <o-button-toggle attr=\"toggle1\" value=\"table\" icon=\"storage\"></o-button-toggle>\r\n        <o-button-toggle attr=\"toggle2\" value=\"grid\" icon=\"view_module\"></o-button-toggle>\r\n      </o-button-toggle-group>\r\n\r\n    </o-table>\r\n\r\n    <o-grid #grid class=\"data-view-grid\" *ngIf=\"defaultView === 'grid'\" [attr]=\"r_attr\" [columns]=\"r_columns\" [configure-service-args]=\"r_configureServiceArgs\"\r\n      [entity]=\"r_entity\" [keys]=\"r_keys\" [pageable]=\"r_pageable\" [paginated-query-method]=\"r_paginatedQueryMethod\" [parent-keys]=\"r_parentKeys\"\r\n      [query-fallback-function]=\"r_queryFallbackFunction\" [query-method]=\"r_queryMethod\" [query-on-bind]=\"r_queryOnBind\"\r\n      [query-on-init]=\"r_queryOnInit\" [query-rows]=\"r_queryRows\" [query-with-null-parent-keys]=\"r_queryWithNullParentKeys\" [service]=\"r_service\"\r\n      [service-type]=\"r_serviceType\" [static-data]=\"r_staticData\" [store-state]=\"r_storeState\" [controls]=\"r_controls\"\r\n      [detail-form-route]=\"r_detailFormRoute\" [detail-mode]=\"r_grid_detailMode\" [enabled]=\"r_grid_enabled\" [quick-filter]=\"r_quickFilter\"\r\n      [quick-filter-placeholder]=\"r_quickFilterPlaceholder\" [quick-filter-appearance]=\"r_quickFilterAppearance\"\r\n      [recursive-detail]=\"r_recursiveDetail\" [title]=\"r_title\" [visible]=\"r_grid_visible\" [cols]=\"r_grid_cols\"\r\n      [fixed-header]=\"r_fixedHeader\" [grid-item-height]=\"r_grid_gridItemHeight\" [gutter-size]=\"r_grid_gutterSize\"\r\n      [insert-button]=\"r_insertButton\" [insert-button-floatable]=\"r_grid_insertButtonFloatable\" [insert-button-position]=\"r_grid_insertButtonPosition\"\r\n      [orderable]=\"r_grid_orderable\" [page-size-options]=\"r_grid_pageSizeOptions\" [pagination-controls]=\"r_paginationControls\"\r\n      [quick-filter-columns]=\"r_grid_quickFilterColumns\" [refresh-button]=\"r_refreshButton\" [show-buttons-text]=\"r_showButtonsText\"\r\n      [show-footer]=\"r_grid_showFooter\" [show-page-size]=\"r_grid_showPageSize\" [sort-column]=\"r_grid_sortColumn\"\r\n      [sortable-columns]=\"r_grid_sortableColumns\">\r\n\r\n      <o-button-toggle-group #toggleGroup *ngIf=\"showToggleOnToolbar\" class=\"toggle-toolbar\" attr=\"toggleGroup\" o-grid-toolbar position=\"end\"\r\n        multiple=\"no\" [value]=\"defaultView\" (onChange)=\"changeView($event)\">\r\n        <o-button-toggle attr=\"toggle1\" value=\"table\" icon=\"storage\"></o-button-toggle>\r\n        <o-button-toggle attr=\"toggle2\" value=\"grid\" icon=\"view_module\"></o-button-toggle>\r\n      </o-button-toggle-group>\r\n\r\n      <o-grid-item *ngFor=\"let row of grid.dataArray; let i = index\">\r\n        <ng-container [ngTemplateOutlet]=\"gridItemTpl?.template\" [ngTemplateOutletContext]=\"{ $implicit: row, row: row, index: i }\">\r\n        </ng-container>\r\n      </o-grid-item>\r\n\r\n    </o-grid>\r\n\r\n    <o-button-toggle-group #toggleGroup *ngIf=\"showToggleFloatable\" class=\"button-toggle-floatable\" attr=\"toggleGroup\" multiple=\"no\"\r\n      [value]=\"defaultView\" (onChange)=\"changeView($event)\">\r\n      <o-button-toggle attr=\"toggle1\" value=\"table\" icon=\"storage\"></o-button-toggle>\r\n      <o-button-toggle attr=\"toggle2\" value=\"grid\" icon=\"view_module\"></o-button-toggle>\r\n    </o-button-toggle-group>\r\n\r\n  </div>\r\n\r\n</div>\r\n", styles: [".button-toggle-group{display:flex;flex-direction:row;justify-content:flex-end;margin-bottom:8px}.button-toggle-floatable{position:fixed;left:calc(50% + 72px);bottom:16px;z-index:1000}.toggle-toolbar{height:32px;width:64px;margin-right:8px}.toggle-toolbar .mat-button-toggle-standalone,.toggle-toolbar .mat-button-toggle-group{height:30px}.toggle-toolbar .mat-button-toggle-standalone .o-button-toggle .mat-button-toggle,.toggle-toolbar .mat-button-toggle-group .o-button-toggle .mat-button-toggle{height:30px;width:32px}.toggle-toolbar .mat-button-toggle-standalone .o-button-toggle .mat-button-toggle span.mat-button-toggle-label-content,.toggle-toolbar .mat-button-toggle-group .o-button-toggle .mat-button-toggle span.mat-button-toggle-label-content{display:flex;padding:0;justify-content:center}:host{display:flex;flex-direction:column;height:100%}.o-data-view-container{flex:1 1 auto;display:flex;flex-direction:column;height:100%}.o-data-view-component{flex:1 1 auto;min-height:0;overflow:hidden;display:flex;flex-direction:column}.data-view-grid{overflow:auto;background-color:#fff}.data-view-grid .o-grid-container{padding:0 .5%}\n"], dependencies: [{ kind: "directive", type: i1$1.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i1$1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: i1$1.NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "component", type: i2.OTableComponent, selector: "o-table", inputs: ["visible-columns", "default-visible-columns", "sort-columns", "quick-filter-function", "delete-button", "refresh-button", "columns-visibility-button", "export-button", "show-configuration-option", "show-buttons-text", "select-all-checkbox", "pagination-controls", "fixed-header", "show-title", "edition-mode", "selection-mode", "horizontal-scroll", "show-paginator-first-last-buttons", "auto-align-titles", "multiple-sort", "select-all-checkbox-visible", "orderable", "resizable", "keep-selected-items", "export-mode", "export-service-type", "auto-adjust", "show-filter-option", "visible-export-dialog-buttons", "row-class", "filter-column-active-by-default", "grouped-columns", "groupable", "expand-groups-same-level", "collapse-grouped-columns", "virtual-scroll", "context-menu", "show-expandable-icon-function", "show-report-on-demand-option", "show-charts-on-demand-option", "show-reset-width-option", "disable-selection-function", "non-hidable-columns", "read-only", "read-only-configuration", "show-notification-of-read-only", "selection-on-row-click"], outputs: ["onRowSelected", "onRowDeselected", "onRowDeleted", "onFilterByColumnChange", "onSortChange", "onSearch"] }, { kind: "component", type: i2.OGridComponent, selector: "o-grid", inputs: ["cols", "show-page-size", "orderable", "sortable-columns", "sort-column", "quick-filter-columns", "grid-item-height", "refresh-button", "gutter-size", "fixed-header", "show-footer", "insert-button-position", "insert-button-floatable", "show-buttons-text"] }, { kind: "component", type: i2.OGridItemComponent, selector: "o-grid-item", inputs: ["colspan", "rowspan"] }, { kind: "component", type: i2.OButtonToggleComponent, selector: "o-button-toggle", inputs: ["attr", "label", "icon", "icon-position", "checked", "enabled", "value", "name"], outputs: ["onChange"] }, { kind: "component", type: i2.OButtonToggleGroupComponent, selector: "o-button-toggle-group", inputs: ["attr", "name", "enabled", "layout", "multiple", "value"], outputs: ["onChange"] }], encapsulation: i0.ViewEncapsulation.None });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: ODataViewComponent, decorators: [{
            type: Component,
            args: [{ selector: 'o-data-view', encapsulation: ViewEncapsulation.None, template: "<div class=\"o-data-view-container\">\r\n\r\n  <o-button-toggle-group #toggleGroup *ngIf=\"!showToggleOnToolbar && !showToggleFloatable && showToggleButton\" class=\"button-toggle-group\"\r\n    attr=\"toggleGroup\" multiple=\"no\" [value]=\"defaultView\" (onChange)=\"changeView($event)\">\r\n    <o-button-toggle attr=\"toggle1\" value=\"table\" icon=\"storage\"></o-button-toggle>\r\n    <o-button-toggle attr=\"toggle2\" value=\"grid\" icon=\"view_module\"></o-button-toggle>\r\n  </o-button-toggle-group>\r\n\r\n  <div class=\"o-data-view-component\">\r\n\r\n    <o-table #table *ngIf=\"defaultView === 'table'\" [attr]=\"r_attr\" [columns]=\"r_columns\" [configure-service-args]=\"r_configureServiceArgs\"\r\n      [entity]=\"r_entity\" [keys]=\"r_keys\" [pageable]=\"r_pageable\" [paginated-query-method]=\"r_paginatedQueryMethod\" [parent-keys]=\"r_parentKeys\"\r\n      [query-fallback-function]=\"r_queryFallbackFunction\" [query-method]=\"r_queryMethod\" [query-on-bind]=\"r_queryOnBind\"\r\n      [query-on-init]=\"r_queryOnInit\" [query-rows]=\"r_queryRows\" [query-with-null-parent-keys]=\"r_queryWithNullParentKeys\" [service]=\"r_service\"\r\n      [service-type]=\"r_serviceType\" [static-data]=\"r_staticData\" [store-state]=\"r_storeState\" [delete-method]=\"r_deleteMethod\"\r\n      [insert-method]=\"r_insertMethod\" [update-method]=\"r_updateMethod\" [controls]=\"r_controls\"\r\n      [detail-button-in-row]=\"r_table_detailButtonInRow\" [detail-button-in-row-icon]=\"r_table_detailButtonInRowIcon\"\r\n      [detail-form-route]=\"r_detailFormRoute\" [detail-mode]=\"r_table_detailMode\" [edit-button-in-row]=\"r_table_editButtonInRow\"\r\n      [edit-button-in-row-icon]=\"r_table_editButtonInRowIcon\" [edit-form-route]=\"r_table_editFormRoute\" [enabled]=\"r_table_enabled\"\r\n      [filter-case-sensitive]=\"r_filterCaseSensitive\" [insert-button]=\"r_insertButton\" [insert-form-route]=\"r_insertFormRoute\"\r\n      [page-size-options]=\"r_table_pageSizeOptions\" [pagination-controls]=\"r_paginationControls\" [quick-filter]=\"r_quickFilter\"\r\n      [quick-filter-placeholder]=\"r_quickFilterPlaceholder\" [recursive-detail]=\"r_recursiveDetail\" [recursive-edit]=\"r_recursiveEdit\"\r\n      [recursive-insert]=\"r_recursiveInsert\" [row-height]=\"r_table_rowHeight\" [title]=\"r_title\" [visible]=\"r_table_visible\"\r\n      [auto-adjust]=\"r_table_autoAdjust\" [auto-align-titles]=\"r_table_autoAlignTitles\" [collapse-grouped-columns]=\"r_table_collapseGroupedColumns\"\r\n      [columns-visibility-button]=\"r_table_columnsVisibilityButton\" [default-visible-columns]=\"r_table_defaultVisibleColumns\"\r\n      [delete-button]=\"r_table_deleteButton\" [disable-selection-function]=\"r_table_disableSelectionFunction\" [edition-mode]=\"r_table_editionMode\"\r\n      [export-button]=\"r_table_exportButton\" [export-service-type]=\"r_table_exportServiceType\"\r\n      [filter-column-active-by-default]=\"r_table_filterColumnActiveByDefault\" [fixed-header]=\"r_fixedHeader\" [groupable]=\"r_table_groupable\"\r\n      [grouped-columns]=\"r_table_groupedColumns\" [horizontal-scroll]=\"r_table_horizontalScroll\" [keep-selected-items]=\"r_table_keepSelectedItems\"\r\n      [multiple-sort]=\"r_table_multipleSort\" [non-hidable-columns]=\"r_table_nonHidableColumns\" [quick-filter-function]=\"r_table_quickFilterFunction\"\r\n      [refresh-button]=\"r_refreshButton\" [resizable]=\"r_table_resizable\" [row-class]=\"r_table_rowClass\"\r\n      [select-all-checkbox]=\"r_table_selectAllCheckbox\" [select-all-checkbox-visible]=\"r_table_selectAllCheckboxVisible\"\r\n      [selection-mode]=\"r_table_selectionMode\" [show-buttons-text]=\"r_showButtonsText\" [show-configuration-option]=\"r_table_showConfigurationOption\"\r\n      [show-expandable-icon-function]=\"r_table_showExpandableIconFunction\" [show-filter-option]=\"r_table_showFilterOption\"\r\n      [show-paginator-first-last-buttons]=\"r_table_showPaginatorFirstLastButtons\" [show-report-on-demand-option]=\"r_table_showReportOnDemandOption\"\r\n      [show-reset-width-option]=\"r_table_showResetWidthOption\" [sort-columns]=\"r_table_sortColumns\"\r\n      [virtual-scroll]=\"r_table_virtualScroll\" [visible-columns]=\"r_table_visibleColumns\"\r\n      [visible-export-dialog-buttons]=\"r_table_visibleExportDialogButtons\" [show-charts-on-demand-option]=\"r_table_showChartsOnDemandOption\" show-title=\"yes\">\r\n\r\n      <o-button-toggle-group #toggleGroup *ngIf=\"showToggleOnToolbar\" class=\"toggle-toolbar\" attr=\"toggleGroup\" o-table-toolbar position=\"end\"\r\n        multiple=\"no\" [value]=\"defaultView\" (onChange)=\"changeView($event)\">\r\n        <o-button-toggle attr=\"toggle1\" value=\"table\" icon=\"storage\"></o-button-toggle>\r\n        <o-button-toggle attr=\"toggle2\" value=\"grid\" icon=\"view_module\"></o-button-toggle>\r\n      </o-button-toggle-group>\r\n\r\n    </o-table>\r\n\r\n    <o-grid #grid class=\"data-view-grid\" *ngIf=\"defaultView === 'grid'\" [attr]=\"r_attr\" [columns]=\"r_columns\" [configure-service-args]=\"r_configureServiceArgs\"\r\n      [entity]=\"r_entity\" [keys]=\"r_keys\" [pageable]=\"r_pageable\" [paginated-query-method]=\"r_paginatedQueryMethod\" [parent-keys]=\"r_parentKeys\"\r\n      [query-fallback-function]=\"r_queryFallbackFunction\" [query-method]=\"r_queryMethod\" [query-on-bind]=\"r_queryOnBind\"\r\n      [query-on-init]=\"r_queryOnInit\" [query-rows]=\"r_queryRows\" [query-with-null-parent-keys]=\"r_queryWithNullParentKeys\" [service]=\"r_service\"\r\n      [service-type]=\"r_serviceType\" [static-data]=\"r_staticData\" [store-state]=\"r_storeState\" [controls]=\"r_controls\"\r\n      [detail-form-route]=\"r_detailFormRoute\" [detail-mode]=\"r_grid_detailMode\" [enabled]=\"r_grid_enabled\" [quick-filter]=\"r_quickFilter\"\r\n      [quick-filter-placeholder]=\"r_quickFilterPlaceholder\" [quick-filter-appearance]=\"r_quickFilterAppearance\"\r\n      [recursive-detail]=\"r_recursiveDetail\" [title]=\"r_title\" [visible]=\"r_grid_visible\" [cols]=\"r_grid_cols\"\r\n      [fixed-header]=\"r_fixedHeader\" [grid-item-height]=\"r_grid_gridItemHeight\" [gutter-size]=\"r_grid_gutterSize\"\r\n      [insert-button]=\"r_insertButton\" [insert-button-floatable]=\"r_grid_insertButtonFloatable\" [insert-button-position]=\"r_grid_insertButtonPosition\"\r\n      [orderable]=\"r_grid_orderable\" [page-size-options]=\"r_grid_pageSizeOptions\" [pagination-controls]=\"r_paginationControls\"\r\n      [quick-filter-columns]=\"r_grid_quickFilterColumns\" [refresh-button]=\"r_refreshButton\" [show-buttons-text]=\"r_showButtonsText\"\r\n      [show-footer]=\"r_grid_showFooter\" [show-page-size]=\"r_grid_showPageSize\" [sort-column]=\"r_grid_sortColumn\"\r\n      [sortable-columns]=\"r_grid_sortableColumns\">\r\n\r\n      <o-button-toggle-group #toggleGroup *ngIf=\"showToggleOnToolbar\" class=\"toggle-toolbar\" attr=\"toggleGroup\" o-grid-toolbar position=\"end\"\r\n        multiple=\"no\" [value]=\"defaultView\" (onChange)=\"changeView($event)\">\r\n        <o-button-toggle attr=\"toggle1\" value=\"table\" icon=\"storage\"></o-button-toggle>\r\n        <o-button-toggle attr=\"toggle2\" value=\"grid\" icon=\"view_module\"></o-button-toggle>\r\n      </o-button-toggle-group>\r\n\r\n      <o-grid-item *ngFor=\"let row of grid.dataArray; let i = index\">\r\n        <ng-container [ngTemplateOutlet]=\"gridItemTpl?.template\" [ngTemplateOutletContext]=\"{ $implicit: row, row: row, index: i }\">\r\n        </ng-container>\r\n      </o-grid-item>\r\n\r\n    </o-grid>\r\n\r\n    <o-button-toggle-group #toggleGroup *ngIf=\"showToggleFloatable\" class=\"button-toggle-floatable\" attr=\"toggleGroup\" multiple=\"no\"\r\n      [value]=\"defaultView\" (onChange)=\"changeView($event)\">\r\n      <o-button-toggle attr=\"toggle1\" value=\"table\" icon=\"storage\"></o-button-toggle>\r\n      <o-button-toggle attr=\"toggle2\" value=\"grid\" icon=\"view_module\"></o-button-toggle>\r\n    </o-button-toggle-group>\r\n\r\n  </div>\r\n\r\n</div>\r\n", styles: [".button-toggle-group{display:flex;flex-direction:row;justify-content:flex-end;margin-bottom:8px}.button-toggle-floatable{position:fixed;left:calc(50% + 72px);bottom:16px;z-index:1000}.toggle-toolbar{height:32px;width:64px;margin-right:8px}.toggle-toolbar .mat-button-toggle-standalone,.toggle-toolbar .mat-button-toggle-group{height:30px}.toggle-toolbar .mat-button-toggle-standalone .o-button-toggle .mat-button-toggle,.toggle-toolbar .mat-button-toggle-group .o-button-toggle .mat-button-toggle{height:30px;width:32px}.toggle-toolbar .mat-button-toggle-standalone .o-button-toggle .mat-button-toggle span.mat-button-toggle-label-content,.toggle-toolbar .mat-button-toggle-group .o-button-toggle .mat-button-toggle span.mat-button-toggle-label-content{display:flex;padding:0;justify-content:center}:host{display:flex;flex-direction:column;height:100%}.o-data-view-container{flex:1 1 auto;display:flex;flex-direction:column;height:100%}.o-data-view-component{flex:1 1 auto;min-height:0;overflow:hidden;display:flex;flex-direction:column}.data-view-grid{overflow:auto;background-color:#fff}.data-view-grid .o-grid-container{padding:0 .5%}\n"] }]
        }], ctorParameters: function () { return [{ type: i0.ViewContainerRef }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [O_TABLE_GLOBAL_CONFIG]
                }] }]; }, propDecorators: { table: [{
                type: ViewChild,
                args: ['table', { static: false }]
            }], grid: [{
                type: ViewChild,
                args: ['grid']
            }], toggleGroup: [{
                type: ViewChild,
                args: ['toggleGroup']
            }], gridItemTpl: [{
                type: ContentChild,
                args: [ODataViewGridItemDirective]
            }], tableTpl: [{
                type: ContentChild,
                args: [ODataViewTableColumnsDirective]
            }], defaultView: [{
                type: Input,
                args: ['default-view']
            }], toggleOnToolbar: [{
                type: Input,
                args: ['toggle-on-toolbar']
            }], toggleFloatable: [{
                type: Input,
                args: ['toggle-floatable']
            }], toggleButton: [{
                type: Input,
                args: ['toggle-button']
            }], attr: [{
                type: Input
            }], columns: [{
                type: Input
            }], configureServiceArgs: [{
                type: Input,
                args: ['configure-service-args']
            }], deleteMethod: [{
                type: Input,
                args: ['delete-method']
            }], entity: [{
                type: Input
            }], insertMethod: [{
                type: Input,
                args: ['insert-method']
            }], keys: [{
                type: Input
            }], pageable: [{
                type: Input
            }], paginatedQueryMethod: [{
                type: Input,
                args: ['paginated-query-method']
            }], parentKeys: [{
                type: Input,
                args: ['parent-keys']
            }], queryFallbackFunction: [{
                type: Input,
                args: ['query-fallback-function']
            }], queryMethod: [{
                type: Input,
                args: ['query-method']
            }], queryOnBind: [{
                type: Input,
                args: ['query-on-bind']
            }], queryOnInit: [{
                type: Input,
                args: ['query-on-init']
            }], queryRows: [{
                type: Input,
                args: ['query-rows']
            }], queryWithNullParentKeys: [{
                type: Input,
                args: ['query-with-null-parent-keys']
            }], service: [{
                type: Input
            }], serviceType: [{
                type: Input,
                args: ['service-type']
            }], staticData: [{
                type: Input,
                args: ['static-data']
            }], storeState: [{
                type: Input,
                args: ['store-state']
            }], updateMethod: [{
                type: Input,
                args: ['update-method']
            }], showButtonsText: [{
                type: Input,
                args: ['show-buttons-text']
            }], quickFilterPlaceholder: [{
                type: Input,
                args: ['quick-filter-placeholder']
            }], insertButton: [{
                type: Input,
                args: ['insert-button']
            }], refreshButton: [{
                type: Input,
                args: ['refresh-button']
            }], fixedHeader: [{
                type: Input,
                args: ['fixed-header']
            }], controls: [{
                type: Input
            }], title: [{
                type: Input
            }], quickFilter: [{
                type: Input,
                args: ['quick-filter']
            }], quickFilterAppearance: [{
                type: Input,
                args: ['quick-filter-appearance']
            }], recursiveDetail: [{
                type: Input,
                args: ['recursive-detail']
            }], recursiveEdit: [{
                type: Input,
                args: ['recursive-edit']
            }], recursiveInsert: [{
                type: Input,
                args: ['recursive-insert']
            }], detailFormRoute: [{
                type: Input,
                args: ['detail-form-route']
            }], paginationControls: [{
                type: Input,
                args: ['pagination-controls']
            }], insertFormRoute: [{
                type: Input,
                args: ['insert-form-route']
            }], filterCaseSensitive: [{
                type: Input,
                args: ['filter-case-sensitive']
            }], tableConfig: [{
                type: Input,
                args: ['table-config']
            }], gridConfig: [{
                type: Input,
                args: ['grid-config']
            }] } });

class ODataViewModule {
}
ODataViewModule.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: ODataViewModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
ODataViewModule.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "15.2.10", ngImport: i0, type: ODataViewModule, declarations: [ODataViewComponent, ODataViewGridItemDirective, ODataViewTableColumnsDirective], imports: [CommonModule, OTableModule, OGridModule, OButtonToggleModule], exports: [ODataViewComponent, ODataViewGridItemDirective, ODataViewTableColumnsDirective] });
ODataViewModule.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: ODataViewModule, imports: [CommonModule, OTableModule, OGridModule, OButtonToggleModule] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: ODataViewModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [ODataViewComponent, ODataViewGridItemDirective, ODataViewTableColumnsDirective],
                    exports: [ODataViewComponent, ODataViewGridItemDirective, ODataViewTableColumnsDirective],
                    imports: [
                        CommonModule, OTableModule, OGridModule, OButtonToggleModule
                    ]
                }]
        }] });

const OEXTRACOMPONENTS_DECLARATION_MODULES = [
    OSkeletonComponent,
    OExtraComponentsTranslatePipe
];
const OEXTRACOMPONENTS_IMPORTS_MODULES = [
    CommonModule,
    NgxSkeletonLoaderModule,
    FlexLayoutModule,
    OntimizeWebModule
];
const OEXTRACOMPONENTS_EXPORT_MODULES = [ODataViewModule];

class OExtraComponentsModule {
}
OExtraComponentsModule.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: OExtraComponentsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
OExtraComponentsModule.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "15.2.10", ngImport: i0, type: OExtraComponentsModule, declarations: [OSkeletonComponent, OExtraComponentsTranslatePipe], imports: [i1$1.CommonModule, i1.NgxSkeletonLoaderModule, i5.FlexLayoutModule, i2.OntimizeWebModule], exports: [ODataViewModule] });
OExtraComponentsModule.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: OExtraComponentsModule, imports: [OEXTRACOMPONENTS_IMPORTS_MODULES, ODataViewModule] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.2.10", ngImport: i0, type: OExtraComponentsModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [...OEXTRACOMPONENTS_DECLARATION_MODULES],
                    imports: [...OEXTRACOMPONENTS_IMPORTS_MODULES],
                    providers: [],
                    exports: [...OEXTRACOMPONENTS_EXPORT_MODULES]
                }]
        }] });

;

;

/*
 * Public API Surface of ontimize-web-ngx-extra-components
 */

/**
 * Generated bundle index. Do not edit.
 */

export { ODataViewComponent, ODataViewGridItemDirective, ODataViewModule, ODataViewTableColumnsDirective, OExtraComponentsModule, OSkeletonComponent };
//# sourceMappingURL=ontimize-web-ngx-extra-components.mjs.map
