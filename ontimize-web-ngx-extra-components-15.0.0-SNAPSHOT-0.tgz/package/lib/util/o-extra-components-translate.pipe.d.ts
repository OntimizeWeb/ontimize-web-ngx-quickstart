import { PipeTransform, Injector } from '@angular/core';
import { OTranslateService } from 'ontimize-web-ngx';
import * as i0 from "@angular/core";
export declare class OExtraComponentsTranslatePipe implements PipeTransform {
    protected injector: Injector;
    protected translateService: OTranslateService;
    constructor(injector: Injector);
    transform(text: string): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<OExtraComponentsTranslatePipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<OExtraComponentsTranslatePipe, "oExtraComponentsTranslate", false>;
}
