export declare const OEXTRACOMPONENTS_DECLARATION_MODULES: any;
export declare const OEXTRACOMPONENTS_IMPORTS_MODULES: any;
export declare const OEXTRACOMPONENTS_EXPORT_MODULES: any;
