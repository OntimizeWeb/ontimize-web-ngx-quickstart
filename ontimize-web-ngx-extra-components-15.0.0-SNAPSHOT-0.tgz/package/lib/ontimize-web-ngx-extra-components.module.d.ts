import * as i0 from "@angular/core";
import * as i1 from "./components/o-skeleton/o-skeleton.component";
import * as i2 from "./util/o-extra-components-translate.pipe";
import * as i3 from "@angular/common";
import * as i4 from "ngx-skeleton-loader";
import * as i5 from "@angular/flex-layout";
import * as i6 from "ontimize-web-ngx";
import * as i7 from "./components/o-data-view/o-data-view.module";
export declare class OExtraComponentsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OExtraComponentsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OExtraComponentsModule, [typeof i1.OSkeletonComponent, typeof i2.OExtraComponentsTranslatePipe], [typeof i3.CommonModule, typeof i4.NgxSkeletonLoaderModule, typeof i5.FlexLayoutModule, typeof i6.OntimizeWebModule], [typeof i7.ODataViewModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OExtraComponentsModule>;
}
