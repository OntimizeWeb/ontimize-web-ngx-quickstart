export declare const MAP: {
    en: {};
    es: {};
};
