import * as i0 from "@angular/core";
import * as i1 from "./o-data-view.component";
import * as i2 from "../../directives/o-data-view-grid-item.directive";
import * as i3 from "../../directives/o-data-view-table-columns.directive";
import * as i4 from "@angular/common";
import * as i5 from "ontimize-web-ngx";
export declare class ODataViewModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ODataViewModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ODataViewModule, [typeof i1.ODataViewComponent, typeof i2.ODataViewGridItemDirective, typeof i3.ODataViewTableColumnsDirective], [typeof i4.CommonModule, typeof i5.OTableModule, typeof i5.OGridModule, typeof i5.OButtonToggleModule], [typeof i1.ODataViewComponent, typeof i2.ODataViewGridItemDirective, typeof i3.ODataViewTableColumnsDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ODataViewModule>;
}
