import * as i0 from "@angular/core";
export declare class OSkeletonComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<OSkeletonComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OSkeletonComponent, "o-skeleton", never, {}, {}, never, never, false, never>;
}
