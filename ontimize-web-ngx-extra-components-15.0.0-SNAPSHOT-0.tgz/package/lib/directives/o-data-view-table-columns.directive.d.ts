import { TemplateRef } from '@angular/core';
import * as i0 from "@angular/core";
export declare class ODataViewTableColumnsDirective {
    templateRef: TemplateRef<any>;
    constructor(templateRef: TemplateRef<any>);
    static ɵfac: i0.ɵɵFactoryDeclaration<ODataViewTableColumnsDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<ODataViewTableColumnsDirective, "ng-template[oDataViewTableColumns]", never, {}, {}, never, never, false, never>;
}
