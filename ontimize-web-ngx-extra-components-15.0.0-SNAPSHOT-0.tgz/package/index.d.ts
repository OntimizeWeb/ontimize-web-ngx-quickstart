/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="ontimize-web-ngx-extra-components" />
export * from './public-api';
